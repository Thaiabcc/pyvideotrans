import json
import time
from pathlib import Path
from typing import List, Optional

from PySide6.QtCore import Qt, QTimer, QSize, QUrl, QThread, Signal, QSettings
from PySide6.QtGui import QIcon, QDesktopServices, QColor
from PySide6.QtMultimedia import QMediaPlayer, QAudioOutput
from PySide6.QtMultimediaWidgets import QVideoWidget
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLineEdit, QLabel, QCheckBox,
    QComboBox, QPushButton, QWidget, QGroupBox, QPlainTextEdit,
    QMessageBox, QTableWidget, QTableWidgetItem,
    QHeaderView, QAbstractItemView, QGridLayout, QSplitter, QStackedLayout
)

from videotrans.component._danspmixin import DanspMixin
from videotrans.configure.config import ROOT_DIR, tr, app_cfg, settings, logger
from videotrans.configure import config
from videotrans.util._srt_parse import ms_to_time_string, get_subtitle_from_srt
from videotrans.util.help_misc import show_error


class SpeakerAssignmentDialog(QDialog,DanspMixin):
    def __init__(
            self,
            parent=None,
            target_language="en",#翻译目标语言代码
            all_voices: Optional[List[str]] = None,#所有角色列表
            cache_folder=None,#缓存目录
            tts_type=0#当前配音渠道ID
    ):
        super().__init__()
        self.parent = parent
        self.target_sub = app_cfg.onlyone_target_sub
        self.source_srtstring = None
        self.source_srt_list_dict = None
        self.cache_folder = cache_folder
        self.target_language = target_language
        self.tts_type = tts_type
        self._target_end_ms = -1

        if app_cfg.onlyone_source_sub:
            sour_pt = Path(app_cfg.onlyone_source_sub)
            if sour_pt.as_posix() and not sour_pt.samefile(Path(self.target_sub)):
                try:
                    self.source_srtstring = sour_pt.read_text(encoding="utf-8-sig")
                    self.source_srt_list_dict = get_subtitle_from_srt(app_cfg.onlyone_source_sub)
                except Exception:
                    self.source_srtstring = ""

        self.srt_list_dict = []  # Defer parsing to background thread

        # 说话人数据初始化
        self.speaker_list_sub = []
        self.speakers = {}
        try:
            spk_json_path = Path(f'{self.cache_folder}/speaker.json')
            _list_sub = [] if not spk_json_path.exists() else json.loads(spk_json_path.read_text(encoding='utf-8'))
            _set = set(_list_sub) if _list_sub else None
            if _set and len(_set) > 1:
                self.speaker_list_sub = _list_sub
                self.speakers = {it: None for it in sorted(list(_set))}
        except Exception as e:
            logger.exception(f'获取说话人id失败:{e}', exc_info=True)

        self.all_voices = all_voices or []

        self.setWindowTitle(tr("zidonghebingmiaohou"))
        self.setWindowIcon(QIcon(f"{ROOT_DIR}/videotrans/styles/icon.ico"))
        self.setMinimumWidth(parent.screen_size[0]*0.95)
        self.setMinimumHeight(parent.screen_size[1]*0.9)
        self.setWindowFlags(
        Qt.WindowStaysOnTopHint |       # 2. 始终在最顶层
            Qt.WindowTitleHint |            # 3. 显示标题栏
            Qt.CustomizeWindowHint |        # 4. 允许自定义标题栏按钮（否则OS会强制加关闭按钮）
            Qt.WindowMaximizeButtonHint     # 5. 只加最大化按钮，不加关闭按钮
        )

        main_layout = QVBoxLayout(self)
        
        # --- 顶部：倒计时与提示 ---
        self.count_down = int(float(settings.get('countdown_sec', 1)))
        top_layout = QVBoxLayout()
        hstop = QHBoxLayout()

        self.prompt_label = QLabel(tr("This window will automatically close after the countdown ends"))
        self.prompt_label.setStyleSheet('color:#aaaaaa')
        self.prompt_label.setWordWrap(True)
        hstop.addWidget(self.prompt_label)

        self.stop_button = QPushButton(f"{tr('Click here to stop the countdown')}({self.count_down})")
        self.stop_button.setStyleSheet("color:#ffff00")
        self.stop_button.setCursor(Qt.PointingHandCursor)
        self.stop_button.setMinimumSize(QSize(300, 35))
        self.stop_button.clicked.connect(self.stop_countdown)
        hstop.addWidget(self.stop_button)

        top_layout.addLayout(hstop)
        prompt_label2 = QLabel(tr("If you need to delete a line of subtitles, just clear the text in that line"))
        prompt_label2.setAlignment(Qt.AlignCenter)
        prompt_label2.setStyleSheet("color: #dddddd")
        prompt_label2.setWordWrap(True)
        top_layout.addWidget(prompt_label2)
        main_layout.addLayout(top_layout)

        # --- 查找替换区域 ---
        search_replace_layout = QHBoxLayout()
        search_replace_layout.addStretch()
        self.search_input = QLineEdit()
        self.search_input.setMaximumWidth(200)
        self.search_input.setPlaceholderText(tr("Original text"))
        search_replace_layout.addWidget(self.search_input)
        self.replace_input = QLineEdit()
        self.replace_input.setPlaceholderText(tr("Replace"))
        self.replace_input.setMaximumWidth(200)
        search_replace_layout.addWidget(self.replace_input)
        replace_button = QPushButton(tr("Replace"))
        replace_button.setMinimumWidth(100)
        replace_button.setMaximumWidth(200)
        replace_button.setCursor(Qt.PointingHandCursor)
        replace_button.clicked.connect(self.replace_text)
        search_replace_layout.addWidget(replace_button)
        search_replace_layout.addStretch()
        main_layout.addLayout(search_replace_layout)

        # ===================== Splitter: video (top) + content (bottom) =====================
        self.splitter = QSplitter(Qt.Vertical)
        self.splitter.setHandleWidth(6)

        # --- Top area: video display (players created lazily on first play) ---
        self.video_widget = QVideoWidget()
        self.video_widget.setStyleSheet("background-color: #1a1a1a;")
        self.video_widget.setMinimumHeight(150)

        self.video_hint = QLabel(tr("Click on a subtitle below to play video"))
        self.video_hint.setStyleSheet("color:#ffcc00;  background-color:transparent;")
        self.video_hint.setAlignment(Qt.AlignCenter)
        self.video_hint.setAttribute(Qt.WA_TransparentForMouseEvents)

        self.video_status = QLabel("")
        self.video_status.setStyleSheet("color:#aaaaaa; font-size:12px;")


        self._stack = QStackedLayout()
        self._stack.addWidget(self.video_widget)
        self._stack.addWidget(self.video_hint)
        self._stack.setCurrentIndex(1)

        videostatus_layout=QHBoxLayout()
        videostatus_layout.setContentsMargins(0, 2, 0, 2)
        self.stop_play_btn=QPushButton()
        self.stop_play_btn.setToolTip(tr('Click to pause playback'))
        self.stop_play_btn.setText(tr('Click to pause playback'))
        self.stop_play_btn.clicked.connect(self._pause_play)
        self.stop_play_btn.setCursor(Qt.PointingHandCursor)
        self.stop_play_btn.hide()
        self.btn_minus = QPushButton("-")
        self.btn_minus.setToolTip(tr('Decrease table font size'))
        self.btn_minus.setFixedWidth(30)
        self.btn_plus = QPushButton("+")
        self.btn_plus.setToolTip(tr('Increase table font size'))
        self.btn_plus.setFixedWidth(30)
        self.btn_plus.clicked.connect(lambda: self.change_table_font_size(2))
        self.btn_minus.clicked.connect(lambda: self.change_table_font_size(-2))
        videostatus_layout.addStretch()
        videostatus_layout.addWidget(self.btn_minus)
        videostatus_layout.addWidget(self.btn_plus)
        videostatus_layout.addWidget(self.stop_play_btn)
        videostatus_layout.addWidget(self.video_status)
        videostatus_layout.addStretch()

        top_container = QWidget()
        top_layout = QVBoxLayout(top_container)
        top_layout.setContentsMargins(0, 0, 0, 0)
        top_layout.addLayout(self._stack)
        top_layout.addLayout(videostatus_layout)
        self.splitter.addWidget(top_container)

        # --- Bottom area: content (existing layout) ---
        bottom_container = QWidget()
        self.content_layout = QVBoxLayout(bottom_container)
        self.content_layout.setContentsMargins(0, 0, 0, 0)
        
        # Loading 区域
        self.loading_widget = QWidget()
        load_layout = QVBoxLayout(self.loading_widget)
        self.loading_label = QLabel(tr('Loading...'), self)
        self.loading_label.setAlignment(Qt.AlignCenter)
        load_layout.addWidget(self.loading_label)
        self.content_layout.addWidget(self.loading_widget)

        # 表格容器
        self.table_container = QWidget()
        self.table_container_layout = QVBoxLayout(self.table_container)
        self.table_container.setVisible(False)
        self.table = QTableWidget()
        sets = QSettings("pyvideotrans", "settings")
        fontsize = int(sets.value("danshipin_table_fontsize", 0))
        if fontsize>0:
            default_font = self.table.font()
            default_font.setPointSize(fontsize)  # 设置为 16px
            self.table.setFont(default_font)
            self.table.horizontalHeader().setFont(default_font)
            self.table.verticalHeader().setFont(default_font)
        self.content_layout.addWidget(self.table_container)
        
        # 底部按钮容器
        self.bottom_button_container = QWidget()
        self.bottom_button_container_layout = QHBoxLayout(self.bottom_button_container)
        self.bottom_button_container.setVisible(False)
        self.content_layout.addWidget(self.bottom_button_container)

        self.splitter.addWidget(bottom_container)
        self.splitter.setSizes([int(parent.height * 0.22), int(parent.height * 0.68)])
        main_layout.addWidget(self.splitter, 1)

        # --- 底部按钮 ---
        self.save_button = QPushButton(tr("nextstep"))
        self.save_button.setCursor(Qt.PointingHandCursor)
        self.save_button.setMinimumSize(QSize(300, 35))
        self.save_button.clicked.connect(self.save_and_close)

        self.save_button2 = QPushButton(tr("nosaveandstep"))
        self.save_button2.setCursor(Qt.PointingHandCursor)
        self.save_button2.setToolTip(tr('bubaocunshuoming', self.target_sub))
        self.save_button2.setMinimumSize(QSize(200, 35))
        self.save_button2.clicked.connect(self.save_and_close2)

        self.opendir_button = QPushButton(tr("opendir_button source_sub"))
        self.opendir_button.setCursor(Qt.PointingHandCursor)
        self.opendir_button.setMaximumSize(QSize(150, 30))
        self.opendir_button.clicked.connect(self.opendir_sub)

        cancel_button = QPushButton(tr("Terminate this mission"))
        cancel_button.setCursor(Qt.PointingHandCursor)
        cancel_button.setStyleSheet("background-color:transparent;color:#ff0")
        cancel_button.setMinimumSize(QSize(150, 30))
        cancel_button.clicked.connect(self.cancel_and_close)

        bottom_layout = QHBoxLayout()
        bottom_layout.addStretch()
        bottom_layout.addWidget(self.save_button)
        bottom_layout.addWidget(self.save_button2)
        bottom_layout.addWidget(self.opendir_button)
        bottom_layout.addWidget(cancel_button)
        bottom_layout.addStretch()

        main_layout.addLayout(bottom_layout)

        # 延迟加载表格
        QTimer.singleShot(200, self.load_table)



    def load_table(self):
        """Load table with background SRT parsing."""
        if not self.isVisible():
            return
        try:
            self.srt_list_dict= get_subtitle_from_srt(self.target_sub)

            self.table.setColumnCount(10)
            self.table.setHorizontalHeaderLabels([
                "Sel",
                tr("Line"),
                tr("Time Axis"),
                tr('Speaker'),
                tr("Dubbing role"),
                '\u270D'+tr("Start Time")+'/s',
                '\u270D'+tr("End Time")+'/s',
                '\u23F5',
                '\u270D'+tr("Subtitle Text"),
                tr("SourceLang Text")])
            
            # 禁用所有视觉效果
            self.table.setAlternatingRowColors(False)
            self.table.setShowGrid(False)  # 不显示网格线
            
            # 禁用选择
            self.table.setSelectionMode(QAbstractItemView.NoSelection)
            self.table.setSelectionBehavior(QAbstractItemView.SelectItems)
            
            # 禁用焦点
            self.table.setFocusPolicy(Qt.NoFocus)
            
            # 长文本自动换行时行高自适应
            self.table.setWordWrap(True)
            self.table.verticalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
            self.table.verticalHeader().setMinimumSectionSize(22)
            self.table.verticalHeader().setVisible(False)
            
            # 列宽设置
            header = self.table.horizontalHeader()
            header.setSectionResizeMode(0, QHeaderView.Fixed)  # Sel
            header.setSectionResizeMode(1, QHeaderView.Fixed)  # line
            header.setSectionResizeMode(2, QHeaderView.ResizeToContents)  # Timex
            header.setSectionResizeMode(3, QHeaderView.ResizeToContents)  # Spk
            header.setSectionResizeMode(4, QHeaderView.ResizeToContents)  # Role
            header.setSectionResizeMode(5, QHeaderView.ResizeToContents)  # Time
            header.setSectionResizeMode(6, QHeaderView.ResizeToContents)  # Time
            header.setSectionResizeMode(7, QHeaderView.Fixed)  # Play
            header.setSectionResizeMode(8, QHeaderView.Stretch)  # Text
            header.setSectionResizeMode(9, QHeaderView.Stretch)  # SourceText
            
            self.table.setColumnWidth(0, 50)
            self.table.setColumnWidth(1, 60)
            self.table.setColumnWidth(2, 100)
            self.table.setColumnWidth(3, 100)
            self.table.setColumnWidth(4, 100)
            self.table.setColumnWidth(5, 100)
            self.table.setColumnWidth(6, 100)
            self.table.setColumnWidth(7, 30)

            # 最小样式
            self.table.setStyleSheet(self.table_style_css)
            
            # 3. 预计算所有显示数据
            speaker_keys = list(self.speakers.keys()) if self.speakers else []
            default_spk = speaker_keys[0] if speaker_keys else ''
            
            self.display_data = []
            for i, item in enumerate(self.srt_list_dict):
                # Speaker ID
                if self.speakers and i < len(self.speaker_list_sub):
                    spk = self.speaker_list_sub[i]
                else:
                    spk = default_spk if self.speakers else ''
                
                # 时间字符串
                self.display_data.append({
                    'line': item['line'],
                    'spk': spk,
                    'text': item['text'],
                    'origin_text': '' if not self.source_srt_list_dict or len(self.source_srt_list_dict)<i+1 else self.source_srt_list_dict[i]['text'],
                    'startraw': item['startraw'],
                    'endraw': item['endraw'],
                    'start_time': item['start_time'],
                    'end_time': item['end_time'],
                    'checked': False,
                    'role': ''
                })
            
            # 4. 设置行数
            total_rows = len(self.display_data)
            self.table.setRowCount(total_rows)
            
            # 5. 渲染行 — 通过 QTimer 分批执行，避免界面冻结
            QTimer.singleShot(0, lambda: self._load_remaining_rows(0))
            
            # 6. 添加到布局
            self.table_container_layout.addWidget(self.table)
            
            # 7. 添加底部按钮
            self._setup_bottom_buttons()
            
            # 8. 显示表格
            self.loading_widget.setVisible(False)
            self.table_container.setVisible(True)
            self.bottom_button_container.setVisible(True)
            
            # 8. 启动倒计时
            self.timer = QTimer(self)
            self.timer.timeout.connect(self.update_countdown)
            self.timer.start(1000)
            self._active()
            self._play_segment(0,5)
            
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.loading_label.setText(f"Error: {e}")

    def _batch_fill_table(self, start_row, end_row):
        """批量填充表格数据 - 减少重绘"""
        for row in range(start_row, end_row):
            data = self.display_data[row]
            
            # 第0列：复选框
            chk_item = QTableWidgetItem()
            chk_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsUserCheckable)
            chk_item.setCheckState(Qt.Unchecked)
            chk_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.table.setItem(row, 0, chk_item)
            
            # 第1列：ID（只读）
            id_item = QTableWidgetItem(str(data['line']))
            id_item.setFlags(Qt.ItemIsEnabled)
            id_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.table.setItem(row, 1, id_item)

            id_item = QTableWidgetItem(f'{data["startraw"]}->{data["endraw"]} ({(data["end_time"]-data["start_time"])/1000.0}s)' )
            id_item.setFlags(Qt.ItemIsEnabled)
            id_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.table.setItem(row, 2, id_item)

            # 第2列：Speaker 
            spk_item = QTableWidgetItem(data['spk'])
            spk_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsEditable | Qt.ItemIsSelectable)
            spk_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.table.setItem(row, 3, spk_item)
            
            # 第3列：Role（只读，显示用）
            role_item = QTableWidgetItem(app_cfg.onlyone_voice_role)
            role_item.setFlags(Qt.ItemIsEnabled)
            role_item.setForeground(QColor("#ff4d4d"))
            role_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.table.setItem(row, 4, role_item)
            
            # 第4列：Time
            time_item = QTableWidgetItem( str(data['start_time']/1000.0 ))
            time_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsEditable | Qt.ItemIsSelectable)
            time_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.table.setItem(row, 5, time_item)

            time_item2 = QTableWidgetItem(str(data['end_time']/1000.0 ))
            time_item2.setFlags(Qt.ItemIsEnabled | Qt.ItemIsEditable | Qt.ItemIsSelectable)
            time_item2.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.table.setItem(row, 6, time_item2)

            # 第5列：Play button
            btn = QPushButton("\u23F5")
            btn.setObjectName("playBtn")
            btn.setCursor(Qt.PointingHandCursor)
            s = data['start_time']
            e = data['end_time']
            btn.clicked.connect(lambda checked=False, _s=s, _e=e: self._play_segment(_s, _e))
            self.table.setCellWidget(row, 7, btn)
            
            # 第6列：Text（可编辑）
            text_item = QTableWidgetItem(data['text'])
            text_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsEditable | Qt.ItemIsSelectable)
            text_item.setTextAlignment(Qt.AlignmentFlag.AlignVCenter)
            self.table.setItem(row, 8, text_item)
            
            origin_text_item = QTableWidgetItem(data['origin_text'])
            origin_text_item.setFlags(Qt.ItemIsEnabled)
            origin_text_item.setTextAlignment(Qt.AlignmentFlag.AlignVCenter)
            self.table.setItem(row, 9, origin_text_item)

    def _load_remaining_rows(self, start_row):
        """延迟加载剩余行 - 避免界面冻结"""
        total = len(self.display_data)
        batch_size = 50  # 每批加载50行
        
        end_row = min(start_row + batch_size, total)
        self._batch_fill_table(start_row, end_row)
        
        if end_row < total:
            # 还有数据，继续加载
            QTimer.singleShot(0, lambda: self._load_remaining_rows(end_row))

    def _setup_bottom_buttons(self):
        """设置底部按钮区域"""
        # 如果有说话人，添加说话人分配区域
        if self.speakers:
            speaker_widget = self._create_speaker_assignment_area()
            # 插入到表格容器之前
            self.content_layout.insertWidget(0, speaker_widget)
        
        # 底部按钮
        self.subtitle_combo = QComboBox()
        self.subtitle_combo.addItems(self.all_voices)
        self.bottom_button_container_layout.addWidget(self.subtitle_combo)

        assign_button = QPushButton(tr("Assign roles to selected subtitles"))
        assign_button.setCursor(Qt.PointingHandCursor)
        assign_button.clicked.connect(self.assign_subtitle_roles)
        assign_button.setMinimumSize(QSize(180, 28))
        self.bottom_button_container_layout.addWidget(assign_button)

        self.listen_button = QPushButton(tr("Trial dubbing"))
        self.listen_button.setCursor(Qt.PointingHandCursor)
        self.listen_button.clicked.connect(self.listen_dubbing)
        self.bottom_button_container_layout.addWidget(self.listen_button)
        
        labe_tips=QLabel(tr('If not specified separately'))
        
        self.bottom_button_container_layout.addWidget(labe_tips)
        self.bottom_button_container_layout.addStretch()

    def _create_speaker_assignment_area(self):
        """创建说话人分配区域"""
        group = QGroupBox("")
        group.setStyleSheet("QGroupBox{border:none;}")
        layout = QVBoxLayout(group)
        label_tips = QLabel(tr("Assign a timbre to each speaker"))
        label_tips.setStyleSheet("color:#aaaaaa")
        layout.addWidget(label_tips)

        self.speaker_checks = {}
        self.speaker_labels = {}

        grid_layout = QGridLayout()
        grid_layout.setContentsMargins(0, 5, 0, 5)
        grid_layout.setHorizontalSpacing(15)
        grid_layout.setVerticalSpacing(5)

        for i, spk_id in enumerate(self.speakers):
            row = i // 4
            col = i % 4
            check = QCheckBox(f'{tr("Speaker")}: {spk_id}')
            check.setStyleSheet("color: #dddddd;")
            
            label = QLabel("")
            label.setMinimumWidth(80)
            label.setStyleSheet("color: #ffcccc;")

            h=QHBoxLayout()
            h.addWidget(check)
            h.addWidget(label)
            h.addStretch()
            grid_layout.addLayout(h,row,col)

            self.speaker_checks[check] = spk_id
            self.speaker_labels[check] = label

        layout.addLayout(grid_layout)

        bottom_row = QHBoxLayout()
        self.speaker_combo = QComboBox()
        self.speaker_combo.addItems(self.all_voices)
        
        lbl = QLabel(tr('Dubbing role'))
        lbl.setStyleSheet("color: #dddddd;")
        bottom_row.addWidget(lbl)
        bottom_row.addWidget(self.speaker_combo)

        assign_button = QPushButton(tr("Assign roles"))
        assign_button.setCursor(Qt.PointingHandCursor)
        assign_button.clicked.connect(self.assign_speaker_roles)
        assign_button.setMinimumSize(QSize(120, 26))
        bottom_row.addWidget(assign_button)
        bottom_row.addStretch()

        layout.addLayout(bottom_row)
        return group

    def assign_speaker_roles(self):
        """分配角色给说话人"""
        selected_role = self.speaker_combo.currentText()
        role_value = None if selected_role == "No" else selected_role

        for check, spk_id in self.speaker_checks.items():
            if check.isChecked():
                self.speakers[spk_id] = role_value
                self.speaker_labels[check].setText(selected_role if role_value else "")
                check.setChecked(False)
        
        # 更新表格中的 Role 列
        self._update_role_column()

    def _update_role_column(self):
        """更新 Role 列显示"""
        for row, data in enumerate(self.display_data):
            # 优先显示行内角色，否则显示说话人对应的全局角色
            role = data.get('role', '')
            if not role and data['spk']:
                role = self.speakers.get(data['spk'], '')
            
            item = self.table.item(row, 4)
            if not item:
                continue
            item.setText(app_cfg.onlyone_voice_role if role in ['No','',None] else role)

    def assign_subtitle_roles(self):
        """分配角色给选中的行"""
        selected_role = self.subtitle_combo.currentText()
        role_value = None if selected_role == "No" else selected_role

        for row in range(self.table.rowCount()):
            chk_item = self.table.item(row, 0)
            if chk_item and chk_item.checkState() == Qt.Checked:
                self.display_data[row]['role'] = role_value
                chk_item.setCheckState(Qt.Unchecked)
        
        self._update_role_column()

    def replace_text(self):
        """替换文本"""
        search_text = self.search_input.text()
        replace_text = self.replace_input.text()

        if not search_text:
            return

        self.table.setUpdatesEnabled(False)  # 禁用更新，提升性能
        
        for row, data in enumerate(self.display_data):
            if search_text in data['text']:
                new_text = data['text'].replace(search_text, replace_text)
                data['text'] = new_text
                item = self.table.item(row, 8)
                if item:
                    item.setText(new_text)
        
        self.table.setUpdatesEnabled(True)  # 恢复更新

    def listen_dubbing(self):
        """试听配音"""
        selected_role = self.subtitle_combo.currentText()
        role_value = None if selected_role == "No" else selected_role
        if not role_value:
            return

        first_text = self.display_data[0]['text'] if self.display_data else ''
        if not first_text:
            return

        from videotrans.util.ListenVoice import ListenVoice
        
        def feed(d):
            self.listen_button.setText(tr("Trial dubbing"))
            self.listen_button.setDisabled(False)
            if d != "ok":
                show_error(d)

        wk = ListenVoice(parent=self, queue_tts=[{
            "text": first_text,
            "role": role_value,
            "filename": config.TEMP_DIR + f"/{time.time()}-onlyone_setrole.wav",
            "tts_type": self.tts_type}],
            language=self.target_language,
            tts_type=self.tts_type)
        wk.uito.connect(feed)
        wk.start()
        self.listen_button.setText('Listening...')
        self.listen_button.setDisabled(True)

    # ===================== Audio-driven sync =====================
    def _pause_play(self):
        self.video_player.pause()
        self._target_end_ms = -1
        self.video_status.setText(tr("Playback stopped"))
        self.stop_play_btn.hide()

    def _ensure_players(self):
        """Create QMediaPlayer instances on first use."""
        if hasattr(self, '_players_created'):
            return
        self._players_created = True

        self.video_player = QMediaPlayer()
        self.video_player.setVideoOutput(self.video_widget)
        self.audio_output = QAudioOutput()
        self.video_player.setAudioOutput(self.audio_output)
        self.audio_output.setVolume(1.0) # 1.0 表示 100% 音量
        self.video_player.positionChanged.connect(self._on_video_position_changed)


    def _on_video_position_changed(self, position):
        if 0 < self._target_end_ms <= position:
            self._pause_play()


    def _play_segment(self, start_ms, end_ms):
        self._ensure_players()
        self.stop_play_btn.show()
        self._pending_start = start_ms
        self._pending_end = end_ms

        self._players_pending = 0
        try:
            if app_cfg.onlyone_name and Path(app_cfg.onlyone_name).exists():
                if not self.video_player.source().toString():
                    self.video_player.setSource(QUrl.fromLocalFile(app_cfg.onlyone_name))
                    self._players_pending += 1
            else:
                self.video_status.setText(tr('No silent video frames generated yet'))
        except Exception as e:
            self.video_status.setText(f"Load failed: {e}")
            return

        if self._players_pending > 0:
            try:
                self.video_player.mediaStatusChanged.disconnect(self._on_media_ready)
            except BaseException:
                pass
            self.video_player.mediaStatusChanged.connect(self._on_media_ready)
            return
        self._do_play(start_ms, end_ms)

    def _on_media_ready(self, status):
        from PySide6.QtMultimedia import QMediaPlayer
        if status in (QMediaPlayer.MediaStatus.BufferedMedia, QMediaPlayer.MediaStatus.LoadedMedia):
            self._players_pending -= 1
            if self._players_pending <= 0:
                self._disconnect_media_signals()
                self._do_play(self._pending_start, self._pending_end)

    def _disconnect_media_signals(self):
        import warnings
        warnings.filterwarnings("ignore", category=RuntimeWarning, message="Failed to disconnect")
        try:
            self.video_player.mediaStatusChanged.disconnect()
        except (TypeError, RuntimeError):
            pass

    def _do_play(self, start_ms, end_ms):
        self._target_end_ms = end_ms
        self.video_player.setPosition(start_ms)
        self.video_player.play()
        self._stack.setCurrentIndex(0)
        self.video_status.setText(f"\u23F5 {ms_to_time_string(ms=start_ms)} → {ms_to_time_string(ms=end_ms)}")

    def _stop_playback(self):
        self._target_end_ms = -1
        if not hasattr(self, '_players_created'):
            return
        try:
            self.video_player.stop()
        except Exception as e:
            logger.exception(e, exc_info=True)

    def _release_media(self):
        if not hasattr(self, '_players_created'):
            return
        self._stop_playback()
        import warnings
        warnings.filterwarnings("ignore", category=RuntimeWarning, message="Failed to disconnect")
        for sig in [self.video_player.positionChanged, self.video_player.mediaStatusChanged]:
            try:
                sig.disconnect()
            except (TypeError, RuntimeError):
                pass
        try:
            self.video_player.setSource(QUrl())
        except Exception:
            pass
        import gc
        gc.collect()

    def _active(self):
        if self.parent:
            self.raise_()                
            self.activateWindow()

    def cancel_and_close(self):
        if hasattr(self, 'timer') and self.timer:
            self.timer.stop()
        self._release_media()
        self.reject()

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            event.ignore()
        else:
            super().keyPressEvent(event)

    def update_countdown(self):
        self.count_down -= 1
        if self.stop_button and hasattr(self.stop_button, 'setText'):
            self.stop_button.setText(f"{tr('Click here to stop the countdown')}({self.count_down})")
        if self.count_down <= 0:
            self.timer.stop()
            self.save_and_close()

    def stop_countdown(self):
        if hasattr(self, 'timer') and self.timer:
            self.timer.stop()
            self.stop_button.deleteLater()
            self.prompt_label.deleteLater()
            self.timer=None

    def save_and_close2(self):
        self.stop_countdown()
        self._release_media()
        self.accept()

    def opendir_sub(self):
        QDesktopServices.openUrl(QUrl.fromLocalFile(Path(self.target_sub).parent.as_posix()))


    def closeEvent(self, event):
        event.ignore()  # 忽略关闭请求，窗口保持不动
    
    def save_and_close(self):
        self.stop_countdown()
        self._release_media()
        self.save_button.setDisabled(True)
        app_cfg.line_roles = {}
        srt_str_list = []


        for row, data in enumerate(self.display_data):
            # 获取当前文本（从表格中获取最新值）
            start_time = self.table.item(row, 5)
            if not start_time:continue
            end_time = self.table.item(row, 6)
            start_raw=ms_to_time_string(ms=int(float(start_time.text().strip())*1000))
            end_raw=ms_to_time_string(ms=int(float(end_time.text().strip())*1000))

            text_item = self.table.item(row, 8)
            text = text_item.text().strip() if text_item else data['text'].strip()
            if not text:continue

            srt_str_list.append(f'{len(srt_str_list)+1}\n{start_raw} --> {end_raw}\n{text}')

            # 角色保存逻辑
            role = data.get('role', '')
            spk= self.table.item(row, 3).text().strip() or data['spk']
            if not role and self.speakers and spk:
                role = self.speakers.get(spk, '')

            if role:
                app_cfg.line_roles[str(data["line"])] = role

        try:
            Path(self.target_sub).write_text("\n\n".join(srt_str_list), encoding="utf-8")
        except Exception as e:
            logger.error(f"Save subtitle failed: {e}")
            QMessageBox.critical(self, "Error", f"Save failed: {e}")
            self.save_button.setDisabled(False)
            return

        self.accept()