# 语音识别，新进程执行
# 返回元组
# 失败：第一个值为False，则为失败，第二个值存储失败原因
# 成功，第一个值存在需要的返回值，不需要时返回True，第二个值为None
import json, traceback
from pathlib import Path
from typing import List, Tuple, Union

from videotrans.configure.config import logger,ROOT_DIR


def paraformer(
        cut_audio_list=None,
        detect_language=None,
        model_name=None,
        logs_file=None,
        is_cuda=False,
        audio_file=None,
        max_speakers=-1,
        cache_folder=None,
        device_index=0,  # gpu索引
        hotword=None,
        **kw
):
    from modelscope.pipelines import pipeline
    from modelscope.utils.constant import Tasks
    from videotrans.util._srt_parse import ms_to_time_string
    from videotrans.process._stt_utils import _write_log
    device=kw.get('device_name','auto')
    if device=='auto':
        device = f'cuda:{device_index}' if is_cuda else 'cpu'
    msg = f'Load {model_name} running on {device}'
    _write_log(logs_file, json.dumps({"type": "logs", "text":msg}))
    logger.debug(f'阿里FunASR渠道使用 {msg}')

    raw_subtitles = []
    try:
        model = pipeline(
            task=Tasks.auto_speech_recognition,
            model=f'{ROOT_DIR}/models/speech_seaco_paraformer_large_asr_nat-zh-cn-16k-common-vocab8404-pytorch',
            # model_revision="v2.0.4",
            vad_model=f'{ROOT_DIR}/models/speech_fsmn_vad_zh-cn-16k-common-pytorch',
            # vad_model_revision="v2.0.4",
            punc_model=f'{ROOT_DIR}/models/punc_ct-transformer_zh-cn-common-vocab272727-pytorch',
            # punc_model_revision="v2.0.3",
            spk_model=f"{ROOT_DIR}/models/speech_campplus_sv_zh-cn_16k-common",
            # spk_model_revision="v2.0.2",
            disable_update=True,
            disable_progress_bar=True,
            disable_log=True,
            device=device,

            # trust_remote_code=True,
        )

        res = model(audio_file,hotword=hotword.replace(',',' '))
        speaker_list = []
        i = 0
        if not res or 'sentence_info' not in res[0]:
            return False, f'No sentence info: {res}'
        for it in res[0]['sentence_info']:
            if not it.get('text', '').strip():
                continue
            i += 1
            if max_speakers > -1:
                speaker_list.append(f"spk{it.get('spk', 0)}")
            tmp = {
                "line": len(raw_subtitles) + 1,
                "text": it['text'].strip(),
                "start_time": it['start'],
                "end_time": it['end'],
                "startraw": f'{ms_to_time_string(ms=it["start"])}',
                "endraw": f'{ms_to_time_string(ms=it["end"])}'
            }
            _write_log(logs_file, json.dumps({"type": "subtitles", "text": f'paraformer-zh [{i}] {it["text"]}\n'}))
            tmp['time'] = f"{tmp['startraw']} --> {tmp['endraw']}"
            raw_subtitles.append(tmp)
        if speaker_list:
            Path(f'{cache_folder}/speaker.json').write_text(json.dumps(speaker_list), encoding='utf-8')
        return raw_subtitles, None
    except BaseException as e:
        msg = traceback.format_exc()
        return False, f'{e}:{msg}'
