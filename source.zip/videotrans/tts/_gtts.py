import logging
import os
from pathlib import Path
from videotrans.util._gtts_timeline import speed_factor, tempo_wav
from videotrans.util.help_ffmpeg import runffmpeg
from dataclasses import dataclass, field
from typing import List, Dict
from typing import Union

from gtts import gTTS
from tenacity import retry, stop_after_attempt, wait_fixed, retry_if_not_exception_type, before_log, after_log
from videotrans.configure.config import tr,params,settings,app_cfg,logger
from videotrans.configure.excepts import NO_RETRY_EXCEPT,StopRetry
from videotrans.tts._base import BaseTTS
from videotrans.util.help_misc import vail_file

RETRY_NUMS = settings.get('retry_nums')
RETRY_DELAY = 5


@dataclass(repr=False)
class GTTS(BaseTTS):

    @retry(retry=retry_if_not_exception_type(NO_RETRY_EXCEPT), stop=(stop_after_attempt(RETRY_NUMS)),
           wait=wait_fixed(RETRY_DELAY), before=before_log(logger, logging.INFO),
           after=after_log(logger, logging.INFO))
    def _run(self, data_item: Union[Dict, List, None], idx: int = -1) -> Union[str, None]:
        if self._exit() or not data_item.get('text','').strip():
            return
        factor = speed_factor(data_item.get('rate', self.rate))
        lans = self.language.split('-')
        if len(lans) > 1:
            self.language = f'{lans[0]}-{lans[1].upper()}'
        response = gTTS(data_item['text'], lang=self.language, lang_check=False)
        response.save(data_item['filename'] + ".mp3")
        # Publish only a complete, speed-adjusted WAV: retries never reuse half-written audio.
        output = data_item['filename']
        raw = output + '.raw.wav'
        processed = output + '.tempo.wav'
        try:
            if not self.convert_to_wav(output + '.mp3', raw):
                raise RuntimeError('gTTS WAV conversion failed')
            if abs(factor - 1) > 1e-9:
                tempo_wav(raw, processed, factor, runffmpeg)
                os.replace(processed, output)
            else:
                os.replace(raw, output)
        finally:
            Path(raw).unlink(missing_ok=True)
            Path(processed).unlink(missing_ok=True)
