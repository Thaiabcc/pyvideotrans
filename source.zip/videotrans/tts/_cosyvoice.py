from dataclasses import dataclass
from typing import Union, Dict, List
from pathlib import Path
from gradio_client import handle_file
from videotrans.tts._gradio import GradioBase
from videotrans.util.help_misc import vail_file


@dataclass(repr=False)
class CosyVoice(GradioBase):
    def __post_init__(self):
        super().__post_init__()
        self.ainame = "cosyvoice"
        self.speed = max(0.5, min(2.0, self.get_speed()))

    def _run(self, data_item: Union[Dict, List, None], idx: int = -1)->Union[str, None]:
        if vail_file(data_item['filename']):return
        ref_wav,prompt_text = self.get_ref_wav(data_item)
        if not ref_wav or not Path(ref_wav).exists() or Path(ref_wav).stat().st_size == 0:
            return f"CosyVoice reference audio is empty or missing: {ref_wav}"

        prompt_text = (prompt_text or "").strip()
        if "<|endofprompt|>" not in prompt_text:
            prompt_text = f"You are a helpful assistant.<|endofprompt|>{prompt_text}"
        kwargs = {
            "tts_text": data_item.get('text', '').strip(),
            "mode_checkbox_group": "3s极速复刻",
            "prompt_wav_upload": handle_file(ref_wav),
            "prompt_wav_record": handle_file(ref_wav),
            "prompt_text": prompt_text,
            "instruct_text": '',#instruct_text,
            "seed": 0,
            "speed": self.speed,
            "stream": False,
            "api_name": "/generate_audio"
        }
        return self._send(kwargs, data_item)
