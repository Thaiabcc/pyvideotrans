import os
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from pathlib import Path
import json
from videotrans import translator
from videotrans.configure._i18n import tr
from videotrans.configure.config import ROOT_DIR,params,defaulelang,TEMP_DIR
from videotrans.tts._base import BaseTTS
from videotrans.util.help_misc import vail_file, is_connect_hf



_MAIN_LANGUAGE={
    "zh":"Chinese",
    "zh-cn":"Chinese",
    "zh-tw":"Chinese",
    "yue":"Chinese",
    "en":"English",
    "ja":"Japanese",
    "ko":"Korean",
    "de":"German",
    "fr":"French",
    "ru":"Russian",
    "pt":"Portuguese",
    "pt-br":"Portuguese",
    "pt-pt":"Portuguese",
    "es":"Spanish",
    "es-419":"Spanish",
    "it":"Italian"
}

@dataclass(repr=False)
class QwenttsLocal(BaseTTS):

    def __post_init__(self):
        super().__post_init__()
        self.model_name="0.6B"


    def _download(self):
        from videotrans.util import help_down
        if Path(f'{ROOT_DIR}/models/models--Qwen--Qwen3-TTS-12Hz-{self.model_name}-Base/model.safetensors').exists() and Path(f'{ROOT_DIR}/models/models--Qwen--Qwen3-TTS-12Hz-{self.model_name}-CustomVoice/model.safetensors').exists():
            return True
        if not is_connect_hf():
            self.local_dir=f'{ROOT_DIR}/models/models--Qwen--Qwen3-TTS-12Hz-{self.model_name}-Base'
            help_down.check_and_down_ms(f'Qwen/Qwen3-TTS-12Hz-{self.model_name}-Base',callback=self._process_callback,local_dir=self.local_dir)
            
            self.local_dir=f'{ROOT_DIR}/models/models--Qwen--Qwen3-TTS-12Hz-{self.model_name}-CustomVoice'
            help_down.check_and_down_ms(f'Qwen/Qwen3-TTS-12Hz-{self.model_name}-CustomVoice',callback=self._process_callback,local_dir=self.local_dir)
        else:
            self.local_dir=f'{ROOT_DIR}/models/models--Qwen--Qwen3-TTS-12Hz-{self.model_name}-Base'
            help_down.check_and_down_hf(model_id=f'Qwen3-TTS-12Hz-{self.model_name}-Base',repo_id=f'Qwen/Qwen3-TTS-12Hz-{self.model_name}-Base',local_dir=self.local_dir,callback=self._process_callback)
            
            self.local_dir=f'{ROOT_DIR}/models/models--Qwen--Qwen3-TTS-12Hz-{self.model_name}-CustomVoice'
            help_down.check_and_down_hf(model_id=f'Qwen3-TTS-12Hz-{self.model_name}-CustomVoice',repo_id=f'Qwen/Qwen3-TTS-12Hz-{self.model_name}-CustomVoice',local_dir=self.local_dir,callback=self._process_callback)


    def _exec(self):

        logs_file = f'{TEMP_DIR}/{self.uuid}/qwen3tts-{time.time()}.log'
        queue_tts_file = f'{TEMP_DIR}/{self.uuid}/queuetts-{time.time()}.json'
        Path(queue_tts_file).write_text(json.dumps(self.queue_tts),encoding='utf-8')
        title="Qwen3-TTS dubbing..."

        kwargs = {
            "queue_tts_file":queue_tts_file,
            "language": _MAIN_LANGUAGE.get(self.language,'auto').capitalize(),
            "logs_file": logs_file,
            "is_cuda": self.is_cuda,
            "model_name":self.model_name,
            "prompt":params.get('qwenttslocal_prompt', ''),
            "is_redubb":self.is_redubb
        }
        from videotrans.process.qwen_tts import qwen3tts_fun
        self._new_process(callback=qwen3tts_fun,title=title,is_cuda=self.is_cuda,kwargs=kwargs)

        if self.is_redubb:return
        self.signal(text=tr('Standardized dubbing segment processing'))
        all_task = []

        with ThreadPoolExecutor(max_workers=min(4,len(self.queue_tts),os.cpu_count())) as pool:
            for item in self.queue_tts:
                if vail_file(item['filename']):continue
                filename=item.get('filename','')+"-24k.wav"
                if  vail_file(filename):
                    all_task.append(pool.submit(self.convert_to_wav, filename,item['filename']))
            if len(all_task) > 0:
                _ = [i.result() for i in all_task]



