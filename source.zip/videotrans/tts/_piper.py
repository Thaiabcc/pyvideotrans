import json
import time
from dataclasses import dataclass
from pathlib import Path

from videotrans.configure._i18n import tr
from videotrans.configure._paths import REDUBB_QUEUE_FILE, REDUBB_STATUS_FILE
from videotrans.configure.constants import GPTW_URL_MS, GPTW_URL_HF
from videotrans.configure.excepts import DubbingSrtError
from videotrans.configure.config import ROOT_DIR,app_cfg,logger
from videotrans.tts._base import BaseTTS
import wave
import builtins
import g2pw.api

from videotrans.util.help_down import down_file_from_hf
from videotrans.util.help_misc import vail_file, is_connect_hf

_original_open = builtins.open

# 修改 g2pw 读取中文默认为gbk编码问题
def _utf8_open(file, mode='r', buffering=-1, encoding=None, *args, **kwargs):
    # 只有在读取文本模式（没有 'b'）且没有指定编码时，才强制设为 utf-8
    if 'b' not in mode and 'r' in mode and encoding is None:
        encoding = 'utf-8'
    return _original_open(file, mode, buffering, encoding, *args, **kwargs)
g2pw.api.open=_utf8_open

from piper import PiperVoice,SynthesisConfig

@dataclass(repr=False)
class PiperTTS(BaseTTS):

    def __post_init__(self):
        super().__post_init__()
        self.speed=self.get_speed()
        self.local_dir=f'{ROOT_DIR}/models/piper'
        
    def _get_model_from_name(self,name):
        # 角色名转为 piper文件夹下的子文件夹名
        name_path=name.split('_')[0]+'/'+name.replace('-','/')
        # 存放onnx文件的最终文件夹绝对路径
        local_dir=f'{self.local_dir}/'+name_path
        onnx_file=f'{local_dir}/{name}.onnx'
        if Path(onnx_file).exists():
            return onnx_file
        url=f'/rhasspy/piper-voices/resolve/main/{name_path}'
        urls=[
            f'{url}/{name}.onnx?download=true',
            f'{url}/{name}.onnx.json?download=true',
        ]
        Path(local_dir).mkdir(exist_ok=True, parents=True)
        down_file_from_hf(local_dir,urls=urls,callback=self._process_callback)
        return onnx_file
    
    def _download(self):
        if not Path(f'{ROOT_DIR}/models/g2pW/g2pw.onnx').exists():
            self.signal(text="Downloading G2PWModel-v2...")
            from videotrans.util.help_down import down_zip
            down_zip(f"{ROOT_DIR}/models",
                           GPTW_URL_MS if not is_connect_hf() else GPTW_URL_HF,
                           self._process_callback)
        return True
    
    def _exec(self):
        # 判断模型是否存在
        role_model={}
        _model_obj={}
        for it in self.queue_tts:
            if it['role'] in role_model or not it.get('text','').strip():
                continue
            role_model[it['role']]=self._get_model_from_name(it['role'])

        syn_config = SynthesisConfig(
            length_scale=self.speed,  # twice as slow
        )
        ok, err = 0, 0
        _except=None
        queue_tts=self.queue_tts
        # 循环，用于轮询重新配音数据，非重新配音时，第一轮直接返回
        while 1:
            if self.is_redubb and Path(REDUBB_STATUS_FILE).exists():
                return True
            if self.is_redubb:
                try:
                    queue_tts=json.loads(Path(REDUBB_QUEUE_FILE).read_text(encoding='utf-8'))
                except (OSError,json.JSONDecodeError) as e:
                    logger.exception(f'supertonic-3: {e}',exc_info=True)
                    raise


            for i,item in enumerate(queue_tts):
                if app_cfg.exit_soft or (self.is_redubb and Path(REDUBB_STATUS_FILE).exists()):
                    return
                if vail_file(item['filename']):
                    ok+=1
                    continue
                if not item.get('text','').strip():
                    continue
                try:
                    _model_file=role_model.get(item['role'])
                    voice=_model_obj.get(_model_file)
                    if voice is None:
                        voice = PiperVoice.load(_model_file,use_cuda=False,download_dir=f'{ROOT_DIR}/models')
                        _model_obj[_model_file]=voice
                    with wave.open(item['filename']+'-24k.wav', "wb") as wav_file:
                        voice.synthesize_wav(item.get('text'), wav_file,syn_config=syn_config)
                    if not vail_file(item['filename']+'-24k.wav'):
                        err+=1
                        continue
                    ok+=1
                    self.convert_to_wav(item['filename']+'-24k.wav',item['filename'])
                    self.signal(text=f"{tr('Dubbing')} {ok}")
                except Exception as e:
                    logger.exception(f'piper dubbing error',exc_info=True)
                    err+=1
                    _except=e
            if self.is_redubb:
                time.sleep(0.5)
                continue
            break



        if ok==0:
            raise _except if _except else DubbingSrtError('piper dubbing error')

        msg=f"{tr('Dubbing')} ended"
        if err > 0 and ok>0:
            msg=f'[{err}] errors, {ok} succeed'

        self.signal(text=msg)
        logger.debug(f'piper配音结束：{msg}')


