from dataclasses import dataclass

from videotrans.configure._i18n import tr
from videotrans.configure.config import logger,ROOT_DIR,app_cfg,TEMP_DIR
from videotrans.util.help_misc import vail_file, is_connect_hf
from videotrans.tts._base import BaseTTS
from pathlib import Path
import json,time,os
from concurrent.futures import ThreadPoolExecutor

@dataclass(repr=False)
class HiggsVoice(BaseTTS):

    def _download(self):
        from videotrans.util import help_down
        if Path(f'{ROOT_DIR}/models/models--multimodalart--higgs-audio-v3-tts-4b-transformers/model.safetensors').exists():
            return True
        help_down.check_and_down_hf(
                    "multimodalart--higgs-audio-v3-tts-4b-transformers",
                    'multimodalart/higgs-audio-v3-tts-4b-transformers',
                    f'{ROOT_DIR}/models/models--multimodalart--higgs-audio-v3-tts-4b-transformers',
                    callback=self._process_callback,
            )
        help_down.check_and_down_hf(
                    "bosonai--higgs-audio-v2-tokenizer",
                    'bosonai/higgs-audio-v2-tokenizer',
                    f'{ROOT_DIR}/models/models--bosonai--higgs-audio-v2-tokenizer',
                    callback=self._process_callback,
            )

        return True
        
    def _exec(self):
        logs_file = f'{TEMP_DIR}/{self.uuid}/higgs-audio-v2-{time.time()}.log'
        queue_tts_file = f'{TEMP_DIR}/{self.uuid}/higgs-audio-v2-{time.time()}.json'
        Path(queue_tts_file).write_text(json.dumps(self.queue_tts),encoding='utf-8')
        title="higgs-audio-TTS dubbing..."
        kwargs = {
            "queue_tts_file":queue_tts_file,
            "logs_file": logs_file,
            "is_cuda": self.is_cuda,
            "speed":1.0,
            "is_redubb":self.is_redubb
        }
        from videotrans.process.higgs_tts import higgs_fun
        self._new_process(callback=higgs_fun,title=title,is_cuda=self.is_cuda,kwargs=kwargs)
        if self.is_redubb:return

        self.signal(text=tr('Standardized dubbing segment processing'))
        all_task = []

        with ThreadPoolExecutor(max_workers=min(4,len(self.queue_tts),os.cpu_count())) as pool:
            for item in self.queue_tts:
                if vail_file(item['filename']):continue
                filename=item.get('filename','')+"-24k.wav"
                if vail_file(filename):
                    all_task.append(pool.submit(self.convert_to_wav, filename,item['filename']))
            if len(all_task) > 0:
                _ = [i.result() for i in all_task]

