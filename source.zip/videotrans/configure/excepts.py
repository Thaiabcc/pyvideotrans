import re,sys
import aiohttp
import requests
from requests.exceptions import TooManyRedirects, MissingSchema, InvalidSchema, InvalidURL, ProxyError, SSLError, \
    Timeout, ConnectionError as ReqConnectionError, RetryError, HTTPError
from tenacity import RetryError as TenRetryError
import httpx
from videotrans.configure.config import defaulelang


# 内部已整理好错误提示消息的异常，将ex=None,message='{错误消息}'
class VideoTransError(Exception):
    def __init__(self, message=''):
        super().__init__(message)
        self.message = message

    def __str__(self):
        return str(self.message)


class TranslateSrtError(VideoTransError):
    pass


class DubbingSrtError(VideoTransError):
    pass


class SpeechToTextError(VideoTransError):
    pass


class LLMSegmentError(VideoTransError):
    pass

class FFmpegError(VideoTransError):
    pass

class DownloadModelsError(VideoTransError):
    pass


class SttTimeoutError(VideoTransError):
    pass




# 出现该类异常时，需要立即停止任务
class StopTask(VideoTransError):
    pass


class StopRetry(VideoTransError):
    pass


# 不可恢复，无需继续重试的异常
NO_RETRY_EXCEPT = (
    ConnectionError,

    TooManyRedirects,  # 重定向次数过多
    InvalidURL,  # URL 格式无效
    # 代理错误
    ProxyError,
    MissingSchema,
    InvalidSchema,
    SSLError,
    ReqConnectionError,

    httpx.ProxyError,
    httpx.ConnectError,
    httpx.InvalidURL,
    httpx.LocalProtocolError,
    httpx.ProtocolError,
    httpx.TooManyRedirects,
    httpx.UnsupportedProtocol,

    StopRetry,
    StopTask
)

"""检查错误信息中是否包含本地地址"""
def _is_local_address(url_or_message):
    if not url_or_message:
        return False

    text = str(url_or_message).lower()
    local_indicators = ['127.0.0.1', 'localhost', '0.0.0.0', '::1', '[::1]']

    return any(indicator in text for indicator in local_indicators)


"""尝试从错误信息中提取API地址"""


def _extract_api_url_from_error(error):
    error_str = str(error)

    # 查找URL模式
    url_patterns = [
        r'https?://[^\s\'"]+',
        r'www\.[^\s\'"]+\.[a-z]{2,}',
        r'[a-zA-Z0-9.-]+\.[a-z]{2,}',
    ]

    for pattern in url_patterns:
        matches = re.findall(pattern, error_str)
        if matches:
            return matches[0]

    return None


"""处理连接错误的详细信息"""


def _handle_connection_error_detail(error, lang):
    error_str = str(error).lower()

    # 检查是否为本地地址
    is_local = _is_local_address(error_str)
    api_url = _extract_api_url_from_error(error)

    base_message = ""

    if "dns" in error_str or "name or service not known" in error_str:
        base_message = (
            "域名解析失败，无法找到服务器地址" if lang == 'zh'
            else "Domain name resolution failed, cannot find server address"
        )
    elif "ProxyError" in error_str:
        base_message = (
            "代理设置不正确或代理不可用，请检查代理或关闭代理并删掉代理文本框中所填内容" if lang == 'zh'
            else "The proxy address is not available, please check"
        )

    elif "refused" in error_str or "10061" in error_str or "积极拒绝" in error_str:
        if is_local:
            base_message = (
                "连接被拒绝，请确保本地服务已启动并正在运行" if lang == 'zh'
                else "Connection refused, please ensure the local service is started and running"
            )
        else:
            base_message = (
                "连接被拒绝，无法连接目标服务" if lang == 'zh'
                else "Connection refused"
            )
    elif "reset" in error_str:
        base_message = (
            "连接被重置，网络可能不稳定" if lang == 'zh'
            else "Connection reset, network may be unstable"
        )
    elif "timeout" in error_str or "timed out" in error_str:
        base_message = (
            "连接超时，请检查网络连接是否稳定" if lang == 'zh'
            else "Connection timeout, please check network stability"
        )
    elif "max retries exceeded" in error_str:
        if is_local:
            if "0.0.0.0" in error_str:
                base_message = (
                    "API 地址不可是 0.0.0.0 ，请修改为 127.0.0.1 " if lang == 'zh'
                    else "The API address cannot be 0.0.0.0, please change it to 127.0.0.1"
                )
            else:
                base_message = (
                    "多次重试连接失败，请确保本地服务已正确启动" if lang == 'zh'
                    else "Multiple connection retries failed, please ensure local service is properly started"
                )
        else:
            base_message = (
                "多次重试连接失败，服务可能暂时不可用" if lang == 'zh'
                else "Multiple connection retries failed, service may be temporarily unavailable"
            )

    else:
        base_message = (
            "网络连接失败" if lang == 'zh'
            else "Network connection failed"
        )

    # 为中文用户添加额外提示
    if lang == 'zh' and api_url and not is_local:
        if "api.msedgeservices.com" in api_url.lower():
            base_message += ". EdgeTTS使用频繁可能触发限流，请稍等段时间重试。"
            return base_message
        if "edge.microsoft.com" in api_url.lower():
            base_message += ". 微软翻译使用频繁可能触发限流，请稍等段时间重试。"
            return base_message
        # 检查是否为国外知名API服务
        foreign_apis = ['openai', 'anthropic', 'claude', 'elevenlabs', 'deepgram', 'google', 'aws.amazon']
        if any(api in api_url.lower() for api in foreign_apis):
            base_message += "。注意：某些国外服务需要科学上网才能访问"

    return base_message



def _nofoundfile(e,lang):
    filename=getattr(e, 'filename', '')
    if sys.platform=='win32' and filename and "/tmp/" not in filename and len(filename)>250:
        return f'请检查文件是否存在，若存在，可能文件名可能过长，请重命名为简短名称，并移动到浅层目录下:\n{filename}' if lang=='zh' else f'The filename may be too long. Please rename it to a shorter name and move it to a shallow directory.:\n{filename}'
    return f"文件不存在：{filename}" if lang == 'zh' else f"File not found: {filename}"

# 根据异常类型，返回整理后的可读性错误消息
def get_msg_from_except(ex:BaseException)->str:
    if isinstance(ex, VideoTransError):
        return str(ex)

    lang = defaulelang
    if isinstance(ex, TenRetryError):
        try:
            ex = ex.last_attempt.exception()
        except AttributeError:
            pass
    from elevenlabs.core import ApiError as ApiError_11
    import httpcore
    from openai import AuthenticationError, PermissionDeniedError, NotFoundError, BadRequestError, RateLimitError, \
    APIConnectionError, APIError, ContentFilterFinishReasonError, InternalServerError, LengthFinishReasonError
    # 异常处理映射
    exception_handlers = {
        # === 认证和权限问题 ===
        AuthenticationError: lambda e: (
            f"API密钥错误，请检查密钥是否正确 {e.message}" if lang == 'zh'
            else (e.body.get('message') if e.body else e.message)
        ),

        PermissionDeniedError: lambda e: (
            f"当前密钥没有访问权限，请检查权限设置 {e.message}" if lang == 'zh'
            else (e.body.get('message') if e.body else e.message)
        ),

        # === 频率限制 ===
        # === 资源不存在问题 ===
        # === 请求参数问题 ===
        # === 服务端问题 ===
        (RateLimitError,InternalServerError, NotFoundError, BadRequestError, APIConnectionError, APIError): lambda e: e.body.get('message') if hasattr(e, 'body') and e.body else e.message,

        LengthFinishReasonError: lambda e: f'内容太长超出最大允许Token，请减小内容或增大max_token,或者降低每次发送字幕行数\n{e}' if lang == 'zh' else f'{e}',
        ContentFilterFinishReasonError: lambda
            e: f"内容触发AI风控被过滤 {e}" if lang == 'zh' else f'Content triggers AI risk control and is filtered\n{e}',

        # === 配置和地址问题 ===
        (TooManyRedirects, MissingSchema, InvalidSchema, InvalidURL): lambda e: (
            f"请求地址格式不正确，请检查配置 {e.message}" if lang == 'zh'
            else f"Request URL format is incorrect, check configuration {e.message}"
        ),

        (ProxyError, aiohttp.client_exceptions.ClientProxyConnectionError): lambda e: (
            "代理设置不正确或代理不可用，请检查代理或关闭代理并删掉代理文本框中所填内容" if lang == 'zh'
            else "Proxy configuration issue, check settings or disable proxy"
        ),
        SSLError: lambda e: (
            "安全连接失败，请检查系统时间或网络设置，如果使用了代理，请关闭后重试" if lang == 'zh'
            else "Secure connection failed, check system time or network settings"
        ),

        (HTTPError, RetryError): lambda e: f'{e}',

        ApiError_11: lambda e: e.body.get('detail', {}).get('message', e.body) if hasattr(e, 'body') else str(e),
        # === 网络连接问题 ===
        (ReqConnectionError, ConnectionError, ConnectionResetError, ConnectionRefusedError, ConnectionAbortedError,
         httpcore.ConnectTimeout, httpx.ConnectTimeout, httpx.ConnectError, httpx.ReadError, Timeout): lambda e: (
            _handle_connection_error_detail(e, lang)
        ),

        (RuntimeError, ValueError, requests.exceptions.RequestException): lambda e: f"{e}",

        FileNotFoundError: lambda e: (
            _nofoundfile(e,lang)
        ),

        PermissionError: lambda e: (
            f"{e}：{getattr(e, 'filename', '')}"
        ),

        FileExistsError: lambda e: (
            f"文件已存在：{getattr(e, 'filename', '')}" if lang == 'zh'
            else f"File already exists: {getattr(e, 'filename', '')}"
        ),

        # === 操作系统错误 ===
        OSError: lambda e: (
            f"系统错误 ({e.errno})：{e.strerror}" if lang == 'zh'
            else f"System Error ({e.errno}): {e.strerror}"
        ),

        # === 数据处理错误 ===
        KeyError: lambda e: (
            f"处理数据时缺少必需的键：{e}" if lang == 'zh'
            else f"{e}"
        ),

        IndexError: lambda e: (
            f"处理列表或序列时索引越界:{e}" if lang == 'zh'
            else f"{e}"
        ),

        LookupError: lambda e: (
            f"查找错误，指定的键或索引不存在:{e}" if lang == 'zh'
            else f"{e}"
        ),

        UnicodeDecodeError: lambda e: (
            f"文件或数据解码失败，编码格式错误：{e.reason}" if lang == 'zh'
            else f" {e.reason}"
        ),

        # === 程序内部错误 ===
        AttributeError: lambda e: (
            f"程序内部错误：{e}" if lang == 'zh'
            else f"{e}"
        ),

        NameError: lambda e: (
            f"程序内部错误：未定义的变量 '{e.name}'" if lang == 'zh' else f"{e}"
        ),

        TypeError: lambda e: (
            f"程序内部错误：{e}" if lang == 'zh'
            else f"{e}"
        ),

        RecursionError: lambda e: (
            f"程序内部错误：发生无限递归:{e}" if lang == 'zh'
            else f"{e}"
        ),

        ZeroDivisionError: lambda e: (
            f"算术错误：除数为零:{e}" if lang == 'zh'
            else f"{e}"
        ),

        OverflowError: lambda e: (
            f"算术错误：数值超出最大限制:{e}" if lang == 'zh'
            else f"{e}"
        ),

        BrokenPipeError: lambda e: (
            "连接管道损坏，请检查网络连接" if lang == 'zh'
            else "Broken pipe error, check network connection"
        ),
    }

    # 遍历映射，查找匹配的处理器
    for exc_types, handler in exception_handlers.items():
        if isinstance(ex, exc_types):
            return handler(ex)

    # === 后备处理逻辑 ===
    error_str = str(ex)
    if any(keyword in error_str.lower() for keyword in [
        'connection', 'connect', 'refused', 'reset', 'timeout', 'retries',
        '连接', '拒绝', '重置', '超时', '重试', 'host', 'port', 'http', 'tcp', 'ProxyError'
    ]):
        return _handle_connection_error_detail(ex, lang)

    _msg = None
    if hasattr(ex, 'detail') and ex.detail:
        _msg = ex.detail
    elif hasattr(ex, 'body') and ex.body:
        _msg = ex.body
    elif hasattr(ex, 'error'):
        _msg = ex.error

    if _msg and isinstance(_msg, dict):
        if message := _msg.get('message'):
            return str(message)
        if error_info := _msg.get('error'):
            if isinstance(error_info, dict):
                return str(error_info.get('message', error_info))
            return str(error_info)
        return str(_msg)
    # 默认错误消息
    return ''
