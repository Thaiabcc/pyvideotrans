import platform
import time
import tempfile
from pathlib import Path
from videotrans.configure.config import tr, app_cfg
from videotrans.configure import constants
from videotrans.configure.constants import LISTEN_TEXT
from videotrans.util.help_misc import open_url, show_error


class WinActionBaseMiscMixin:

    def check_cuda(self, state):
        res = state
        if platform.system() == 'Darwin':
            self.cfg['is_cuda'] = False
            return
        if state and app_cfg.NVIDIA_GPU_NUMS == 0:
            show_error(tr('nocuda'))
            self.main.enable_cuda.setChecked(False)
            self.main.enable_cuda.setDisabled(True)
            res = False
        self.cfg['is_cuda'] = res

    def check_voice_autorate(self, state):
        if state:
            self.main.remove_silent_mid.setVisible(False)
            self.main.align_sub_audio.setVisible(False)
        elif not self.main.video_autorate.isChecked():
            self.main.remove_silent_mid.setVisible(True)
            self.main.align_sub_audio.setVisible(True)

    def check_video_autorate(self, state):
        if state:
            self.main.remove_silent_mid.setVisible(False)
            self.main.align_sub_audio.setVisible(False)
        elif not self.main.voice_autorate.isChecked():
            self.main.remove_silent_mid.setVisible(True)
            self.main.align_sub_audio.setVisible(True)

    def cuda_isok(self):
        if not self.main.enable_cuda.isChecked() or platform.system() == 'Darwin':
            self.cfg['is_cuda'] = False
            return True

        if app_cfg.NVIDIA_GPU_NUMS == 0:
            self.cfg['is_cuda'] = False
            show_error(tr("nocuda"))
            return False
        self.cfg['is_cuda'] = True
        return True

    def listen_voice_fun(self):
        from videotrans import translator
        from videotrans.util.ListenVoice import ListenVoice
        lang = translator.get_code(show_text=self.main.target_language.currentText())
        if not lang:
            return show_error(
                tr("Please select the target language first"))
        
        text = LISTEN_TEXT.get(lang.split('-')[0])
        if not text:
            return show_error(tr("The voice is not support listen")+f' {lang=}')
        role = self.main.voice_role.currentText()
        if not role or role == 'No':
            return show_error(tr('mustberole'))

        voice_dir = tempfile.gettempdir() + '/pyvideotrans'
        if not Path(voice_dir).exists():
            Path(voice_dir).mkdir(parents=True, exist_ok=True)
        rate = int(self.main.voice_rate.value())
        if rate >= 0:
            rate = f"+{rate}%"
        else:
            rate = f"{rate}%"

        volume = int(self.main.volume_rate.value())
        volume = f'+{volume}%' if volume >= 0 else f'{volume}%'
        pitch = int(self.main.pitch_rate.value())
        pitch = f'+{pitch}Hz' if pitch >= 0 else f'{volume}Hz'
        tts_type=self.main.tts_type.currentIndex()
        voice_file = f"{voice_dir}/{tts_type}-{time.time()}.wav"
        obj = {
            "text": text,
            "rate": rate,
            "role": role,
            "filename": voice_file,
            "tts_type": tts_type,
            "language": lang,
            "volume": volume,
            "pitch": pitch,
        }
        if role == 'clone':
            show_error(
                tr("The original sound clone cannot be auditioned"))
            return
        raw_text = self.main.listen_btn.text()
        def feed(d):
            self.main.listen_btn.setDisabled(False)
            self.main.listen_btn.setText(raw_text)
            if d != "ok":
                show_error(d)

        self.main.listen_btn.setDisabled(True)
        self.main.listen_btn.setText('load...')
        wk = ListenVoice(parent=self.main, queue_tts=[obj], language=lang, tts_type=obj['tts_type'])
        wk.uito.connect(feed)
        wk.start()

    def show_listen_btn(self, role):
        voice_role = self.main.voice_role.currentText()
        from videotrans import tts
        _tip = tts.clone_tips(voice_role)
        if _tip:
            self.main.show_tips.setText(_tip)
        if role == 'No' or voice_role == 'clone':
            self.main.listen_btn.hide()
            return
        if self.main.app_mode in ['biaozhun']:
            self.main.listen_btn.show()
            self.main.listen_btn.setDisabled(False)

    def check_name(self):
        if self.main.app_mode != 'tiqu':
            for it in self.queue_mp4:
                if Path(it).suffix.lower() in constants.AUDIO_EXITS:
                    self.main.app_mode = 'tiqu'
                    break
        return True

    @staticmethod
    def open_url(title):
        open_url(title)
