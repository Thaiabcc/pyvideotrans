import os
import platform
import shutil
import subprocess
import sys
import getpass
from pathlib import Path


class LifecycleMixin:

    def restart_app(self):
        from PySide6.QtWidgets import QMessageBox
        from videotrans.configure.config import tr

        reply = QMessageBox.question(
            self,
            tr("Restart"),
            tr("Are you sure you want to restart the application?"),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )

        if reply == QMessageBox.StandardButton.Yes:
            self.is_restarting = True
            self.close()

    @staticmethod
    def kill_ffmpeg_processes():
        from videotrans.configure.config import logger

        current_user = getpass.getuser()
        if platform.system() == "Windows":
            try:
                result = subprocess.run(
                    f'taskkill /F /FI "USERNAME eq {current_user}" /IM ffmpeg.exe',
                    shell=True,
                    capture_output=True,
                    text=True
                )
                if result.returncode != 0:
                    logger.warning(f"taskkill returned: {result.returncode}, output: {result.stdout}")
            except Exception as e:
                logger.exception(f"Error using taskkill: {e}", exc_info=True)

            return

        try:
            result = subprocess.run(
                ['pkill', '-9', '-u', current_user, 'ffmpeg'],
                capture_output=True,
                text=True
            )
            if result.returncode != 0:
                logger.warning(f"pkill returned: {result.returncode}", exc_info=True)
        except Exception as e:
            logger.exception(f"Error using pkill: {e}", exc_info=True)

    def closeEvent(self, event):
        self.hide()
        from videotrans.configure.config import app_cfg, ROOT_DIR, TEMP_DIR, TEMP_ROOT,REDUBB_STATUS_FILE
        try:
            if Path(REDUBB_STATUS_FILE).exists():
                Path(REDUBB_STATUS_FILE).write_text('end')
        except OSError:
            pass
        app_cfg.exit_soft = True
        app_cfg.current_status = 'stop'
        os.chdir(ROOT_DIR)
        self.cleanup_and_accept()

        try:
            shutil.rmtree(TEMP_DIR, ignore_errors=True)
        except OSError:
            pass
        # 清理 TEMP_ROOT 下的 txt srt json 文件，
        # 不直接删除 tmp 文件夹，避免同时启动多个实例导致其他报错，保留 pid 状态文件，防止其他实例出错
        for it in Path(TEMP_ROOT).iterdir():
            if it.is_file() and it.suffix.lower()!='pid':
                try:
                    it.unlink()
                except Exception:
                    pass

        if not self.is_restarting:
            event.accept()
            return

        if getattr(sys, 'frozen', False):
            subprocess.Popen([sys.executable] + sys.argv[1:])
        else:
            subprocess.Popen([sys.executable, sys.argv[0]] + sys.argv[1:])

        event.accept()
        os._exit(0)

    def cleanup_and_accept(self):
        from PySide6.QtCore import QCoreApplication, QSettings, QThreadPool
        from videotrans.configure.config import app_cfg, logger

        QCoreApplication.processEvents()
        sets = QSettings("pyvideotrans", "settings")
        sets.setValue("windowSize", self.size())
        try:
            for w in app_cfg.child_forms.values():
                if w and hasattr(w, 'hide'):
                    w.hide()
        except Exception as e:
            logger.exception(f'子窗口隐藏中出错 {e}', exc_info=True)

        for thread in self.worker_threads:
            if thread and thread.isRunning():
                thread.requestInterruption()

        # 等待所有线程安全结束
        for thread in self.worker_threads:
            if thread and thread.isRunning():
                thread.wait(3000)  # 等待3秒

        try:
            for w in app_cfg.child_forms.values():
                if w and hasattr(w, 'close'):
                    w.close()
        except Exception as e:
            logger.exception(f'子窗口关闭中出错{e}', exc_info=True)

        QThreadPool.globalInstance().waitForDone(5000)
        self.kill_ffmpeg_processes()
