"""Pitch-preserving gTTS tempo and bounded-memory, immutable SRT placement."""
import json
import math
import os
from pathlib import Path
import wave


def speed_factor(rate):
    value = 1 + float(str(rate).strip().rstrip('%')) / 100
    if not math.isfinite(value) or not 0 < value <= 2:
        raise ValueError('gTTS Speed must be greater than -100% and at most +100% (2x).')
    return value


def tempo_wav(source, destination, factor, runffmpeg):
    filters = []
    while factor < 0.5:
        filters.append('atempo=0.5')
        factor /= 0.5
    while factor > 2:
        filters.append('atempo=2')
        factor /= 2
    filters.append(f'atempo={factor:.12g}')
    runffmpeg(['-y', '-i', str(source), '-af', ','.join(filters),
               '-ar', '48000', '-ac', '2', '-c:a', 'pcm_s16le', str(destination)], force_cpu=True)
    with wave.open(str(destination), 'rb') as audio:
        if not audio.getnframes():
            raise ValueError('FFmpeg generated empty audio')


def merge_timeline(queue, target, cache, runffmpeg, cancelled=lambda: False):
    """Leave failed/unfittable cues silent and retain their source audio in report."""
    sample_rate = 48000
    target = Path(target)
    temporary = target.with_name(target.stem + '.timeline.tmp.wav')
    report_path = target.with_suffix('.timeline.json')
    issues = []
    total = max((round(it['end_time'] * 48) for it in queue), default=0)
    if total <= 0:
        raise ValueError('SRT has no positive timeline')
    cursor = 0
    if any(queue[i]['start_time'] > queue[i + 1]['start_time'] for i in range(len(queue) - 1)):
        raise ValueError('SRT cues must be ordered by start time')

    def silence(output, frames):
        block = b'\0' * (48000 * 4)
        while frames > 0:
            if cancelled():
                raise RuntimeError('gTTS timeline cancelled')
            count = min(frames, 48000)
            output.writeframesraw(block[:count * 4])
            frames -= count

    try:
        with wave.open(str(temporary), 'wb') as output:
            output.setparams((2, 2, sample_rate, 0, 'NONE', 'not compressed'))
            for index, item in enumerate(queue):
                if cancelled():
                    raise RuntimeError('gTTS timeline cancelled')
                start = round(item['start_time'] * 48)
                end = round(item['end_time'] * 48)
                issue = dict(line=item.get('line', index + 1), start_ms=item['start_time'],
                             end_ms=item['end_time'], audio=item.get('filename'))
                if start < cursor or end <= start or start < 0:
                    issues.append(dict(issue, reason='invalid_or_overlapping_srt'))
                    continue
                silence(output, start - cursor)
                cursor = start
                # Reserve the next cue's start even for overlapping input subtitles.
                next_starts = [round(queue[index + 1]['start_time'] * 48)] if index + 1 < len(queue) else []
                available = min([end] + next_starts) - start
                source = item.get('filename')
                try:
                    if available <= 0:
                        raise ValueError('invalid_or_overlapping_srt')
                    if not source or not Path(source).is_file():
                        raise ValueError('missing_tts_audio')
                    with wave.open(str(source), 'rb') as audio:
                        if (audio.getnchannels(), audio.getsampwidth(), audio.getframerate()) != (2, 2, sample_rate):
                            raise ValueError('unexpected_audio_format')
                        frames = audio.getnframes()
                    if frames <= 0:
                        raise ValueError('empty_tts_audio')
                    if frames > available:
                        base_factor = speed_factor(item.get('rate', '+0%'))
                        factor = frames / available
                        # Small headroom avoids cutting speech for atempo rounding error.
                        factor = min(factor / 0.98, 2 / base_factor)
                        if base_factor * frames / available > 2 + 1e-9:
                            raise ValueError('required_speed_exceeds_2x')
                        fitted = Path(cache) / f'gtts-fit-{index}.wav'
                        tempo_wav(source, fitted, factor, runffmpeg)
                        source = fitted
                    with wave.open(str(source), 'rb') as audio:
                        frames = audio.getnframes()
                        if frames > available:
                            raise ValueError('audio_still_exceeds_window_no_truncation')
                        while True:
                            block = audio.readframes(48000)
                            if not block:
                                break
                            output.writeframesraw(block)
                        cursor += frames
                except Exception as exc:
                    issues.append(dict(issue, reason=str(exc)))
            silence(output, total - cursor)
        with wave.open(str(temporary), 'rb') as result:
            if result.getnframes() != total:
                raise ValueError('Final WAV duration differs from SRT timeline')
        report_path.write_text(json.dumps(dict(total_ms=total / 48, max_speed=2,
                                               issue_count=len(issues), issues=issues),
                                          ensure_ascii=False, indent=2), encoding='utf-8')
        os.replace(temporary, target)
    finally:
        temporary.unlink(missing_ok=True)
    return issues, str(report_path)
