import json
import re
from typing import List
from videotrans.configure.config import ROOT_DIR, tr, settings, params, logger
from pathlib import Path
from functools import lru_cache
from videotrans.configure import constants, config


@lru_cache
def get_camb_role(force=False, raise_exception=False):
    from . import help_misc
    jsonfile = f'{ROOT_DIR}/videotrans/voicejson/camb.json'
    namelist = ["No", "clone"]
    if help_misc.vail_file(jsonfile):
        with open(jsonfile, 'r', encoding='utf-8-sig') as f:
            cache = json.loads(f.read())
            for it in cache.values():
                name = it.get('voice_name', it.get('name', ''))
                if name:
                    namelist.append(name)
    if not force and len(namelist) > 2:
        params['camb_role'] = namelist
        return namelist
    try:
        from camb.client import CambAI
        import os
        client = CambAI(api_key=params.get("camb_api_key", '') or os.environ.get('CAMB_API_KEY', ''))
        voiceslist = client.voice_cloning.list_voices()

        result = {}
        for it in voiceslist:
            voice_id = it.id if hasattr(it, 'id') else it.get('id')
            voice_name = it.voice_name if hasattr(it, 'voice_name') else it.get('voice_name', '')
            n = re.sub(r'[^a-zA-Z0-9_ -]+', '', voice_name, flags=re.I | re.S).strip()
            if n:
                result[n] = {"name": n, "voice_name": n, "id": voice_id}
        namelist = ['No', 'clone'] + list(result.keys())
        with open(jsonfile, 'w', encoding="utf-8") as f:
            f.write(json.dumps(result))
        params['camb_role'] = namelist
        return namelist
    except Exception as e:
        logger.exception(f'Failed to get CAMB AI voices: {e}', exc_info=True)
        if raise_exception:
            raise
    return []

@lru_cache
def get_elevenlabs_role():
    from . import help_misc
    jsonfile = f'{ROOT_DIR}/videotrans/voicejson/elevenlabs.json'
    namelist = ["No"]
    if help_misc.vail_file(jsonfile):
        with open(jsonfile, 'r', encoding='utf-8-sig') as f:
            cache = json.loads(f.read())
            for it in cache.values():
                namelist.append(it['name'])
    return namelist
def update_elevenlabs_role():
    from elevenlabs import ElevenLabs
    client = ElevenLabs(api_key=params.get("elevenlabstts_key", ''))
    voiceslist = client.voices.get_all()
    namelist = ['No']
    result = {}
    for it in voiceslist.voices:
        n = re.sub(r'[^a-zA-Z0-9_ -]+', '', it.name, flags=re.I | re.S).strip()
        result[n] = {"name": n, "voice_id": it.voice_id}
        namelist.append(n)
    jsonfile = f'{ROOT_DIR}/videotrans/voicejson/elevenlabs.json'
    with open(jsonfile, 'w', encoding="utf-8") as f:
        f.write(json.dumps(result,indent=4))
    return namelist


@lru_cache
def get_deepgram_role(langcode="en"):
    res = ['No']
    file_path = f"{ROOT_DIR}/videotrans/voicejson/deepgram.json"
    rolelist = json.loads(Path(file_path).read_text(encoding='utf-8-sig'))
    res.extend(rolelist.get(langcode,[]))

    return res


@lru_cache
def get_vits_role():
    zh = ['No', "zh_female","zh_en"]
    en = ['No', "en_female","zh_en"]
    for i in range(109):
        en.append(f'en_{i}')
    for i in range(174):
        zh.append(f'zh_{i}')

    return {"zh": {k: k for k in zh}, "en": {k: k for k in en}}

@lru_cache
def get_piper_role():
    file_path = f"{ROOT_DIR}/videotrans/voicejson/piper.json"
    if Path(file_path).exists():
        rolelist = json.loads(Path(file_path).read_text(encoding='utf-8-sig'))
    else:
        rolelist = {}
        from videotrans.translator import LANGNAME_DICT
        langkeys = [it.split('-')[0] for it in LANGNAME_DICT.keys()]
        for it in Path(f'{ROOT_DIR}/models/piper').rglob('*.onnx'):
            rolename = Path(it).stem
            tmp = rolename.split('_')  # tmp[0] 语言代码
            if tmp[0] not in langkeys:
                continue
            if tmp[0] not in rolelist:
                rolelist[tmp[0]] = {"No": "No"}
            rolelist[tmp[0]][rolename] = rolename
        Path(file_path).write_text(json.dumps(rolelist, indent=4), encoding='utf-8')
    return rolelist

@lru_cache
def get_302ai():
    role_dict = get_azure_rolelist()

    with open(ROOT_DIR + "/videotrans/voicejson/302.json", 'r', encoding='utf-8-sig') as f:
        ai302_voice_roles = json.loads(f.read())
        _doubao = ai302_voice_roles.get("AI302_doubao", {})
        _minimaxi = ai302_voice_roles.get("AI302_minimaxi", {})
        _dubbingx = ai302_voice_roles.get("AI302_dubbingx", {})
        _doubao_ja = ai302_voice_roles.get("AI302_doubao_ja", {})
    _openai = constants.OPENAITTS_ROLES.split(",")
    role_dict['zh'] = role_dict['zh'] | _doubao | _minimaxi | _dubbingx | {k: k for k in _openai}
    role_dict['ja'] = role_dict['ja'] | _doubao_ja
    return role_dict

def _resolve_role(roles_dict, role_name, default=None):
    if not roles_dict or not role_name:
        return default
    res = roles_dict.get(role_name)
    if res is not None:
        return res
    if role_name in roles_dict.values():
        return role_name
    return default

# https://docs.volcengine.com/docs/DoubaoVoice/Tonelist-1?lang=zh
@lru_cache
def get_doubao2_rolelist(role_name=None, langcode="zh"):
    roledata = json.loads(Path(f'{ROOT_DIR}/videotrans/voicejson/doubao2.json').read_text(encoding='utf-8-sig'))

    if role_name:
        current_d = roledata.get(langcode.split('-')[0])
        if not current_d:
            return 'No'
        return _resolve_role(current_d, role_name)

    return {key: ['No'] + list(item.keys()) for key, item in roledata.items()}


#  get role by edge tts
@lru_cache(maxsize=None)
def get_edge_rolelist(role_name=None, locale=None):
    from . import help_misc
    voice_list = {}
    voice_file = ROOT_DIR + "/videotrans/voicejson/edge_tts.json"
    if help_misc.vail_file(voice_file):
        try:
            with open(voice_file, 'r', encoding='utf-8-sig') as f:
                voice_list = json.loads(f.read())
            for i, it in voice_list.items():
                voice_list[i] = {"No": "No"} | it
        except (OSError, json.JSONDecodeError):
            pass
    if role_name and locale:
        roles_dict = voice_list.get(locale.split('-')[0], {})
        return _resolve_role(roles_dict, role_name)
    return voice_list

@lru_cache
def get_azure_rolelist(language=None, role_name=None):
    voice_file = ROOT_DIR + "/videotrans/voicejson/azure_voice_list.json"
    voice_list = json.loads(Path(voice_file).read_text(encoding='utf-8-sig'))
    # 根据角色显示名字获取真实角色
    if language and role_name:
        roles_dict = voice_list.get(language, {})
        return _resolve_role(roles_dict, role_name)
    if role_name and (not language or language == 'auto'):
        for it in voice_list.values():
            for name, ro in it.items():
                if name == role_name:
                    return ro
            if role_name in it.values():
                return role_name
        return None
    try:
        for k, it in voice_list.items():
            it['No'] = 'No'
            voice_list[k] = {"No": "No"} | it
    except (OSError, json.JSONDecodeError):
        pass
    return voice_list

@lru_cache
def get_minimaxi_rolelist():
    from . import help_misc
    voice_list = {}
    voice_file = ROOT_DIR + "/videotrans/voicejson/minimaxi.json"

    if params.get("minimaxi_api", '') == 'api.minimax.io':
        voice_file = ROOT_DIR + "/videotrans/voicejson/minimaxiio.json"
    if help_misc.vail_file(voice_file):
        try:
            with open(voice_file, 'r', encoding='utf-8-sig') as f:
                voice_list = json.loads(f.read())
            for i, it in voice_list.items():
                voice_list[i] = {"No": "No"} | it
        except (OSError, json.JSONDecodeError):
            pass
    return voice_list
@lru_cache
def get_fishaudio_rolelist():
    from . import help_misc
    voice_list = {}
    voice_file = ROOT_DIR + "/videotrans/voicejson/fishaudio.json"

    if help_misc.vail_file(voice_file):
        try:
            with open(voice_file, 'r', encoding='utf-8-sig') as f:
                voice_list = json.loads(f.read())
            for i, it in voice_list.items():
                voice_list[i] = {"No": "No"} | it
        except (OSError, json.JSONDecodeError):
            pass
    return voice_list

@lru_cache
def get_qwen3tts_rolelist():
    voices = json.loads(Path(ROOT_DIR + "/videotrans/voicejson/qwen3tts.json").read_text(encoding='utf-8-sig'))
    voices = {"No": "No"} | voices
    return voices


# 本地qwentts3
def get_qwenttslocal_rolelist():
    voices = {
        "Vivian": "Vivian",
        "Serena": "Serena",
        "Uncle_fu": "Uncle_fu",
        "Dylan": "Dylan",
        "Eric": "Eric",
        "Ryan": "Ryan",
        "Aiden": "Aiden",
        "Ono_anna": "Ono_anna",
        "Sohee": "Sohee"
    }
    return get_f5tts_role() | voices

@lru_cache
def get_supertonic_rolelist():
    voices = json.loads(Path(ROOT_DIR + "/videotrans/voicejson/supertonic.json").read_text(encoding='utf-8-sig'))
    voices = {"No": "No"} | voices
    return voices

@lru_cache
def get_glmtts_rolelist():
    voices = json.loads(Path(ROOT_DIR + "/videotrans/voicejson/glmtts.json").read_text(encoding='utf-8-sig'))
    voices = {"No": "No"} | voices
    return voices

@lru_cache
def get_kokoro_rolelist():
    return json.loads(Path(ROOT_DIR + "/videotrans/voicejson/kokoro.json").read_text(encoding='utf-8-sig'))



# 根据 gptsovits params['gptsovits_role'] 返回以参考音频为key的dict
def get_gptsovits_role():
    rolelist = {"No": "No", "clone": "clone"}
    if not params.get('gptsovits_role', '').strip():
        return rolelist
    for it in params.get('gptsovits_role', '').strip().split("\n"):
        tmp = it.strip().split('#')
        if len(tmp) != 3:
            continue
        rolelist[tmp[0]] = {"refer_wav_path": tmp[0], "prompt_text": tmp[1], "prompt_language": tmp[2]}
    return rolelist


def get_chatterbox_role():
    rolelist=get_f5tts_role()
    rolelist["default"]='default'
    return rolelist

def get_f5tts_role():
    rolelist = {"No": "No", "clone": "clone"}
    if not params.get('f5tts_role', '').strip():
        return rolelist
    for it in params.get('f5tts_role', '').strip().split("\n"):
        tmp = it.strip().split('#')
        if len(tmp) != 2:
            continue
        rolelist[tmp[0]] = {"ref_wav": tmp[0], "ref_text": tmp[1]}
    return rolelist


# 获取clone-voice的角色列表
def get_clone_role(set_p=False):
    from . import help_misc
    if not params.get('clone_api', ''):
        if set_p:
            raise Exception(tr('bixutianxiecloneapi'))
        return False
    try:
        import requests
        url = params.get('clone_api', '').strip().rstrip('/') + "/init"
        res = requests.get('http://' + url.replace('http://', ''), proxies={"http": "", "https": ""})
        res.raise_for_status()
        params["clone_voicelist"] = ",".join(['No', "clone"] + res.json())
        help_misc.set_process(type='refreshtts')
    except Exception:
        if set_p: raise
    return False

def get_openrouter_role(model_name):
    rolelist=['No']
    d=json.loads(Path(f'{ROOT_DIR}/videotrans/voicejson/openrouter.json').read_text(encoding="utf-8"))
    _r=d.get(model_name)
    if not _r:
        return rolelist
    rolelist.extend(_r.split(','))
    return rolelist

# 根据渠道返回角色列表 供下拉菜单使用
def role_menu(tts_type, langcode=None) -> List:
    from videotrans import tts
    if tts_type == tts.DEEPGRAM_TTS:
        return get_deepgram_role(langcode)

    if tts_type == tts.OPENROUTER_API:
        return get_openrouter_role(config.params.get("openrouter_tts_model"))

    if tts_type == tts.SILICONFLOW_API:
        return ['No'] + constants.SILICONFLOW_ROLES.split(',')

    if tts_type == tts.OPENAI_TTS:
        return ['No'] + (params.get('openaitts_role') or constants.OPENAITTS_ROLES).split(',')

    if tts_type == tts.XAI_TTS:
        return ['No'] + constants.XAITTS_ROLES.split(',')

    if tts_type == tts.XIAOMI_TTS:
        return ['No'] + constants.MITTS_ROLES.split(',')

    if tts_type == tts.BAILIAN_TTS:
        return list(get_qwen3tts_rolelist().keys())

    if tts_type == tts.Supertonic_TTS:
        return list(get_supertonic_rolelist().keys())

    if tts_type == tts.GLM_TTS:
        return list(get_glmtts_rolelist().keys())

    if tts_type == tts.GEMINI_TTS:
        return constants.GEMINITTS_ROLES.split(',')

    if tts_type == tts.ELEVENLABS_TTS:
        return get_elevenlabs_role()
    if tts_type == tts.G_TTS:
        return ['No','gtts']
    
    if tts_type == tts.CAMB_TTS:
        return get_camb_role()

    if tts_type == tts.CLONE_VOICE_TTS:
        _list = params.get("clone_voicelist",'').split(',')
        return _list

    if tts_type == tts.CHATTTS:
        return ['No'] + list(str(settings.get('chattts_voice','')).split(','))

    if tts_type == tts.TTS_API:
        _f5=list(get_f5tts_role().keys())
        _customs=params.get('ttsapi_voice_role', '').strip()
        if _customs:
            return  _f5 + _customs
        return _f5

    if tts_type == tts.GPTSOVITS_TTS:
        return list(get_gptsovits_role().keys())

    if tts_type == tts.QWEN3LOCAL_TTS:
        return list(get_qwenttslocal_rolelist().keys())

    if tts_type==tts.OMNIVOICE_TTS:
        return list(get_f5tts_role().keys())+['default']

    if tts_type in [tts.AUDIOCPP_TTS,tts.F5_TTS, tts.INDEX_TTS, tts.SPARK_TTS, tts.VOXCPM_TTS,   tts.COSYVOICE_TTS, tts.FISHTTS, tts.MOSS_TTS,tts.CONFUCIUS_TTS,tts.ZIPVOICE_TTS,tts.HIGGS_AUDIO_TTS,tts.FIRERED3_TTS]:
        return list(get_f5tts_role().keys())

    if tts_type == tts.CHATTERBOX_TTS:
        return list(get_chatterbox_role().keys())
    # 语言无关角色一致的到此结束
    # 以下均根据语言代码返回对应角色
    if not langcode:
        return ['No']

    _roledict = None
    if tts_type == tts.EDGE_TTS:
        _roledict = get_edge_rolelist()
    elif tts_type == tts.KOKORO_TTS:
        _roledict = get_kokoro_rolelist()
    elif tts_type == tts.PIPER_TTS:
        _roledict = get_piper_role()
    elif tts_type == tts.VITSCNEN_TTS:
        _roledict = get_vits_role()
    elif tts_type == tts.AI302_TTS:
        _roledict = get_302ai()
    elif tts_type == tts.DOUBAO2_TTS:
        _roledict = get_doubao2_rolelist()
    elif tts_type == tts.MINIMAXI_TTS:
        _roledict = get_minimaxi_rolelist()
    elif tts_type == tts.FISHAUDIOAPI_TTS:
        _roledict = get_fishaudio_rolelist()
    else:
        # AzureTTS
        _roledict = get_azure_rolelist()

    if not _roledict:
        return ['No']
    _roles=_roledict.get(langcode) or _roledict.get(langcode.split('-')[0])
    if not _roles:
        return ['No']
    return _roles if isinstance(_roles, list) else list(_roles.keys())


