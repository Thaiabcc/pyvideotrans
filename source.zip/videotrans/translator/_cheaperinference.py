from dataclasses import dataclass
from videotrans.configure.config import params
from videotrans.translator._openaicompat import OpenAICampat


@dataclass(repr=False)
class CheaperInference(OpenAICampat):

    def __post_init__(self):
        self.ainame = 'cheaperinference'
        self.max_tokens = int(params.get('cheaperinference_max_token', 8192))
        self.model_name = params.get('cheaperinference_model', 'gpt-5.4-mini')
        self.api_url = 'https://api.cheaperinference.com/v1'
        self.api_key = params.get('cheaperinference_key', '')

        super().__post_init__()
