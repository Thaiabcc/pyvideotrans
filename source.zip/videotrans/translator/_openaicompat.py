# -*- coding: utf-8 -*-
import logging
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Union
from openai import OpenAI, LengthFinishReasonError,NotFoundError, AuthenticationError, PermissionDeniedError,BadRequestError,APIConnectionError,APIError
from tenacity import before_log, retry_if_not_exception_type, wait_fixed, stop_after_attempt, after_log, retry

from videotrans.configure.excepts import NO_RETRY_EXCEPT, TranslateSrtError, LLMSegmentError, StopTask
from videotrans.configure.config import logger, settings, ROOT_DIR, tr

from videotrans.task.taskcfg import SrtItem
from videotrans.translator._base import BaseTrans
from videotrans.util._srt_parse import get_subtitle_from_srt, ms_to_time_string
from videotrans.util.help_misc import  get_tanslate_type


@dataclass(repr=False)
class OpenAICampat(BaseTrans):

    def __post_init__(self):
        super().__post_init__()
        self.temperature=float(settings.get('aitrans_temperature', 1.0))
        self.prompt=self._set_context()

        try:
            self.max_tokens=int(self.max_tokens)
        except (ValueError,TypeError) as e:
            logger.error(f'当前渠道{self.ainame}设置的最大输出tokens错误，应填写整数，实际填写的是`{self.max_tokens}`\n{e}')
            self.max_tokens=8192

    def _create_completion(self, kwargs):
        """Issue the chat completion. Overridable so channels can swap the
        transport (e.g. the LiteLLM channel routes through the litellm SDK)
        while reusing the shared prompt building, parsing and error handling.
        """
        model = OpenAI(api_key=self.api_key, base_url=self.api_url)
        return model.chat.completions.create(**kwargs, extra_body=self.extra_body)

    @retry(retry=retry_if_not_exception_type(NO_RETRY_EXCEPT), stop=(stop_after_attempt(settings.get('retry_nums'))), wait=wait_fixed(2), before=before_log(logger, logging.INFO),after=after_log(logger, logging.INFO))
    def _item_task(self, data: str) -> str:
        """

        Args:
            data: 1. 是AI翻译渠道并且选中了`发送完整字幕`：data是  SRT格式字幕字符串
                 2. 是传统翻译渠道或未选`发送完整字幕`：data是  多行字幕文本字符串

        Returns:
            str

        """
        if self._exit(): return
        if len(self.api_url)<10:
            raise StopTask(f'API URL is error: {self.api_url}')
        
        text = data
        
        message = [
            {
                'role': 'system',
                'content': 'You are a top-tier Subtitle Translation Engine.'},
            {
                'role': 'user',
                'content': self.prompt.replace('{batch_input}', f'{text}')
            },
        ]


        kwargs={
            "model":self.model_name,
            "timeout":300,
            "temperature":float(self.temperature)            
        }
        # 针对 openai 官方或 GPT模型，使用 max_completion_tokens 参数，其他第三方使用 max_tokens 参数            
        if "api.openai.com" in self.api_url or (self.ainame=='chatgpt' and re.match(r'^(gpt|o\d)', self.model_name, flags=re.I)):
            kwargs["max_completion_tokens"]=int(self.max_tokens)
        else:
            kwargs["max_tokens"]=int(self.max_tokens)
        
        if self.reasoning_effort:
            kwargs["reasoning_effort"]=self.reasoning_effort
            
        logger.debug(f'字幕翻译:{self.ainame=},{kwargs=},{self.extra_body=}')
        kwargs["messages"]=message

        
        try:
            response = self._create_completion(kwargs)
            result = response.choices[0].message.content.strip()
            match = re.search(r'<TRANSLATE_TEXT>(.*?)</TRANSLATE_TEXT>', re.sub(r'<think>(.*?)</think>', '',result,flags=re.I), flags=re.S|re.I)
            if match:
                return match.group(1)
            return result.strip()
        except APIConnectionError as e:
            raise StopTask(f'[{self.ainame}] {tr("Unable to connect to API",self.api_url)}\n{e.message}') from e
        except (NotFoundError,AuthenticationError,PermissionDeniedError,BadRequestError) as e:
            del kwargs['messages']
            _msg=(e.body.get('message') if e.body else e.message) or str(e)
            raise StopTask(f'{_msg}\n{self.api_url}\n{kwargs}\n{self.extra_body}') from e
        except APIError as e: 
            if re.search(r"insufficient.*?balance",e.message,flags=re.I):
                raise StopTask(tr('The server returned an error message: Insufficient balance',get_tanslate_type(self.translate_type),self.api_url))
            raise
            



    def llm_segment(self, srt_list,step='')->List[SrtItem]:
        _st=time.time()
        flag="LLM纠错"
        if not step and settings.get('llm_resegment'):
            flag="LLM重新断句替换LLM纠错"
            prompts_template = Path(f'{ROOT_DIR}/videotrans/prompts/resegment/llm_re.txt').read_text(encoding='utf-8').replace('{max_speech_s}',str(settings.get('max_speech_duration_s',5)))
        else:
            prompts_template = Path(f'{ROOT_DIR}/videotrans/prompts/resegment/llm.txt').read_text(encoding='utf-8')
        chunk_size = int(settings.get('llm_chunk_size', 20))

        kwargs={
                "model":self.model_name,
                "temperature":self.temperature,
                "timeout":600,   
        }
        if self.reasoning_effort:
            kwargs["reasoning_effort"]=self.reasoning_effort

        if "api.openai.com" in self.api_url or ( self.ainame=='chatgpt' and re.match(r'^(gpt|o\d)', self.model_name, flags=re.I)):
            kwargs["max_completion_tokens"]=int(self.max_tokens)
        else:
            kwargs["max_tokens"]=int(self.max_tokens)
        logger.debug(f'{self.ainame=},{kwargs=},{self.model_name=},{self.api_url=},{step=}')
        
        @retry(retry=retry_if_not_exception_type(NO_RETRY_EXCEPT), stop=(stop_after_attempt(2)),
               wait=wait_fixed(5), before=before_log(logger, logging.INFO),
               after=after_log(logger, logging.INFO))
        def _send(srt):
            nonlocal kwargs
            
            message = [
                {"role": "system", "content": prompts_template},
                {
                    'role': 'user',
                    'content': f"""```srt\n{srt}\n```"""
                }
            ]
            kwargs["messages"]=message
            response = self._create_completion(kwargs)
            
            result = response.choices[0].message.content or ""
            match = re.search(r'<SRT>(.*?)</SRT>', re.sub(r'<think>(.*?)</think>', '', result, flags=re.I | re.S), flags=re.S | re.I)
            if match:
                return match.group(1)
            return result.strip()
            
        
        new_sublist = []
        logger.debug(f'{flag}:{srt_list=}')
        for idx in range(0, len(srt_list), chunk_size):
            self.signal(text=f'[{idx}] {self.ainame} ' + tr("Re-segmenting..."))
            srt_str = "\n\n".join(
                [f"{line + 1}\n{it['time']}\n{it['text']}" for line, it in enumerate(srt_list[idx: idx + chunk_size])])
            new_sublist.append(_send(srt_str))

        logger.debug(f'{flag}:{new_sublist=}')
        _srtlist = get_subtitle_from_srt("\n\n".join(new_sublist), is_file=False)
        # 修正可能存在的时间戳错误
        _len = len(_srtlist)
        for i, it in enumerate(_srtlist):
            _had_edit = False
            if i < _len - 1 and it['end_time'] > _srtlist[i + 1]['start_time']:
                it['end_time'] = _srtlist[i + 1]['start_time']
                _had_edit = True
            if it['start_time'] > it['end_time']:
                it['start_time'] = it['end_time']
                _had_edit = True
            if _had_edit:
                it['startraw'] = ms_to_time_string(ms=it['start_time'])
                it['endraw'] = ms_to_time_string(ms=it['end_time'])
                it["time"] = f"{it['startraw']} --> {it['endraw']}"
        logger.debug(f'{"【二次识别后】"  if step else ""} {flag},原始字幕行:{len(srt_list)}, 新字幕行:{len(_srtlist)}, 用时:{time.time()-_st}s')
        return _srtlist
