import json
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import List,  Union
from videotrans.configure import config
from videotrans.configure.config import settings,ROOT_DIR
from videotrans.recognition._base import BaseRecogn
from videotrans.task.taskcfg import SrtItem
from videotrans.util.help_down import check_and_down_ms,check_and_down_hf
from videotrans.util.help_misc import is_connect_hf


@dataclass(repr=False)
class FunasrRecogn(BaseRecogn):

    def _exec(self) -> Union[List[SrtItem], None]:
        if self._exit():
            return
        from videotrans.process.stt_paraformer import paraformer
        from videotrans.process.stt_funasr import funasr_mlt
        check_and_down_ms(model_id='iic/punc_ct-transformer_zh-cn-common-vocab272727-pytorch',callback=self._process_callback,local_dir=f'{ROOT_DIR}/models/punc_ct-transformer_zh-cn-common-vocab272727-pytorch')

        _lang=self.detect_language.split('-')[0]
        if self.model_name == 'paraformer-zh' and _lang !='zh':
            self.model_name = 'FunAudioLLM/Fun-ASR-MLT-Nano-2512' if _lang not in ['zh','en','ja','yue'] else 'FunAudioLLM/Fun-ASR-Nano-2512'
        elif self.model_name == 'SenseVoiceSmall':
            self.model_name = 'iic/SenseVoiceSmall'
        elif self.model_name == 'Fun-ASR-Nano-2512':
            if _lang not in ['zh', 'en', 'ja', 'yue']:
                self.model_name = f'FunAudioLLM/Fun-ASR-MLT-Nano-2512'
            else:
                self.model_name = f'FunAudioLLM/Fun-ASR-Nano-2512'
        elif self.model_name != 'paraformer-zh':
            self.model_name = f'FunAudioLLM/Fun-ASR-MLT-Nano-2512'
        
        # 固定从 modelscope.cn 下载
        if self.model_name == 'paraformer-zh':
            check_and_down_ms(model_id='iic/speech_fsmn_vad_zh-cn-16k-common-pytorch',callback=self._process_callback,local_dir=f'{ROOT_DIR}/models/speech_fsmn_vad_zh-cn-16k-common-pytorch')
            check_and_down_ms(model_id='iic/speech_seaco_paraformer_large_asr_nat-zh-cn-16k-common-vocab8404-pytorch',callback=self._process_callback,local_dir=f'{ROOT_DIR}/models/speech_seaco_paraformer_large_asr_nat-zh-cn-16k-common-vocab8404-pytorch')
            check_and_down_ms(model_id='damo/speech_campplus_sv_zh-cn_16k-common',callback=self._process_callback,local_dir=f'{ROOT_DIR}/models/speech_campplus_sv_zh-cn_16k-common')
        # 其他模型不能连接 hf时也从 modelscope.cn 下载
        elif  not is_connect_hf():
            check_and_down_ms(model_id=self.model_name,callback=self._process_callback,local_dir=f'{ROOT_DIR}/models/'+self.model_name.split('/')[-1])
        # 能连接hf，并且名字为iic/SenseVoiceSmall 需改为 FunAudioLLM/SenseVoiceSmall 
        elif self.model_name == 'iic/SenseVoiceSmall':
            check_and_down_hf(model_id='FunAudioLLM/SenseVoiceSmall',repo_id='FunAudioLLM/SenseVoiceSmall',callback=self._process_callback,local_dir=f'{ROOT_DIR}/models/'+self.model_name.split('/')[-1])
        else:
            # 其他模型均从hf下载
            check_and_down_hf(model_id=self.model_name,repo_id=self.model_name,callback=self._process_callback,local_dir=f'{ROOT_DIR}/models/'+self.model_name.split('/')[-1])
        self.signal(text=f"load {self.model_name}")
        logs_file = f'{config.TEMP_DIR}/{self.uuid}/funasr-{self.detect_language}-{time.time()}.log'
        if self.model_name != 'paraformer-zh':
            cut_audio_list_file = f'{config.TEMP_DIR}/{self.uuid}/cut_audio_list_{time.time()}.json'
            Path(cut_audio_list_file).write_text( json.dumps( [ asdict(item) for item in self.cut_audio() ] ),encoding='utf-8')
        else:
            cut_audio_list_file=None
        kwars = {
            "cut_audio_list":   cut_audio_list_file,
            "detect_language": self.detect_language,
            "model_name": self.model_name,
            "logs_file": logs_file,
            "is_cuda": self.is_cuda,
            "audio_file": self.audio_file,
            "max_speakers": self.max_speakers,
            "cache_folder": self.cache_folder,
            "hotword":settings.get('hotwords'),

        }
        raws=self._new_process(callback=paraformer if self.model_name == 'paraformer-zh' else funasr_mlt,title=f'STT use {self.model_name}',is_cuda=self.is_cuda,kwargs=kwars)
        return raws
