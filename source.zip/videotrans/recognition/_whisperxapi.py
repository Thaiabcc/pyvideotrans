import json
from dataclasses import dataclass
from pathlib import Path
from typing import List,  Union
from openai import OpenAI,APIConnectionError
from videotrans.configure.excepts import SpeechToTextError,StopTask
from videotrans.configure.config import params,logger,tr
from videotrans.recognition._base import BaseRecogn
from videotrans.task.taskcfg import SrtItem
from videotrans.util._srt_parse import ms_to_time_string


@dataclass(repr=False)
class WhisperXRecogn(BaseRecogn):

    def __post_init__(self):
        super().__post_init__()
        self.api_url = params.get('whisperxapi_api','http://127.0.0.1:9092')


    def _exec(self) -> Union[List[SrtItem], None]:
        if self._exit(): return
        client = OpenAI(
            api_key='123456',
            base_url=self.api_url.rstrip('/')+"/v1"
        )
        raws = []
        speaker_list = []
        speaker_name = []
        logger.debug(f'[whisperx-api]:指定最大说话人：{self.max_speakers=}')
        try:
            with open(self.audio_file, 'rb') as file:
                transcript = client.audio.transcriptions.create(
                    file=(self.audio_file, file.read()),
                    model=self.model_name,
                    language=self.detect_language.split('-')[0],
                    response_format="diarized_json",
                    extra_body={
                      "max_speakers": self.max_speakers #-1不启用，0=不限制数量，>0 最大数量
                    },
                )

                if not hasattr(transcript, 'segments') or not transcript.segments:
                    raise SpeechToTextError('No support')
                for it in transcript.segments:
                    startraw,endraw=ms_to_time_string(ms=it.start * 1000),ms_to_time_string( ms=it.end * 1000)
                    raws.append(SrtItem(
                        line=len(raws) + 1,
                        start_time=it.start * 1000,
                        end_time=it.end * 1000,
                        text=it.text,
                        startraw=startraw,
                        endraw=endraw,
                        time=f'{startraw} --> {endraw}'
                    ))
                    if self.max_speakers>-1:
                        sp = getattr(it,"speaker",'-')
                        speaker_list.append(sp)
                        if sp not in speaker_name:
                            speaker_name.append(sp)

        except APIConnectionError as e:
            raise StopTask(f'[WhisperX] {tr("This channel needs deployed and started before available")}\n{self.api_url=}\n{e}\n[https://pyvideotrans.com/whisperx-api]') from e
        if speaker_name:
            try:
                #默认未识别出后的回退说话人
                next_spk=f'spk{len(speaker_name)}'
                for i,it in enumerate(speaker_list):
                    if it=='-':
                        speaker_list[i]=next_spk
                    else:
                        speaker_list[i]=f'spk{speaker_name.index(it)}'
                if speaker_list:
                    Path(f'{self.cache_folder}/speaker.json').write_text(json.dumps(speaker_list), encoding='utf-8')
            except Exception as e:
                logger.exception(f'说话人重排序出错，忽略{e}',exc_info=True)
        
        return raws


