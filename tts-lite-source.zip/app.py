"""Vietnamese desktop UI for gTTS and Microsoft Edge online TTS."""
import asyncio
import os
from pathlib import Path
import queue
import sys
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, ttk

from core import Cancelled, Engine, parse_srt, read_document


class App:
    def __init__(self, root):
        self.root = root
        root.title('TTS Lite • gTTS + Edge TTS • Auto-fit SRT')
        root.geometry('960x730')
        root.minsize(780, 620)
        self.events = queue.Queue()
        self.cancelled = threading.Event()
        self.busy = False
        self.last_output = None
        self.provider = tk.StringVar(value='gTTS')
        self.mode = tk.StringVar(value='Văn bản')
        self.language = tk.StringVar(value='vi')
        self.voice = tk.StringVar(value='vi-VN-HoaiMyNeural')
        self.speed = tk.StringVar(value='1.0')
        self.status = tk.StringVar(value='Sẵn sàng. Nhập văn bản hoặc import file SRT.')
        style = ttk.Style()
        if 'vista' in style.theme_names():
            style.theme_use('vista')
        style.configure('TButton', padding=(12, 7))
        style.configure('Title.TLabel', font=('Segoe UI', 22, 'bold'))
        style.configure('Sub.TLabel', foreground='#586575')
        folder = Path(getattr(sys, '_MEIPASS', Path(__file__).parent))
        try:
            root.iconbitmap(str(folder / 'icon.ico'))
        except tk.TclError:
            pass

        frame = ttk.Frame(root, padding=24)
        frame.pack(fill='both', expand=True)
        ttk.Label(frame, text='Tạo giọng đọc', style='Title.TLabel').pack(anchor='w')
        ttk.Label(frame, text='gTTS và Edge TTS online · Văn bản / SRT → MP3 / WAV', style='Sub.TLabel').pack(anchor='w', pady=(3, 18))
        controls = ttk.Frame(frame)
        controls.pack(fill='x')
        for col in range(4):
            controls.columnconfigure(col, weight=1)
        ttk.Label(controls, text='Dịch vụ').grid(row=0, column=0, sticky='w')
        self.provider_box = ttk.Combobox(controls, textvariable=self.provider, values=['gTTS', 'Edge TTS'], state='readonly', width=15)
        self.provider_box.grid(row=1, column=0, sticky='ew', padx=(0, 14), pady=(5, 12))
        self.provider_box.bind('<<ComboboxSelected>>', self.update_provider)
        ttk.Label(controls, text='Kiểu nội dung').grid(row=0, column=1, sticky='w')
        self.mode_box = ttk.Combobox(controls, textvariable=self.mode, values=['Văn bản', 'SRT'], state='readonly', width=14)
        self.mode_box.grid(row=1, column=1, sticky='ew', padx=(0, 14), pady=(5, 12))
        ttk.Label(controls, text='Ngôn ngữ gTTS').grid(row=0, column=2, sticky='w')
        self.lang_box = ttk.Combobox(controls, textvariable=self.language, values=['vi', 'en', 'ja', 'ko', 'zh-CN', 'zh-TW', 'fr', 'de', 'es', 'ru', 'th', 'id'], width=14)
        self.lang_box.grid(row=1, column=2, sticky='ew', padx=(0, 14), pady=(5, 12))
        ttk.Label(controls, text='Tốc độ (0.5x – 2x)').grid(row=0, column=3, sticky='w')
        self.speed_box = ttk.Spinbox(controls, from_=.5, to=2, increment=.1, textvariable=self.speed, width=12)
        self.speed_box.grid(row=1, column=3, sticky='ew', pady=(5, 12))

        voices = ttk.Frame(frame)
        voices.pack(fill='x', pady=(0, 14))
        ttk.Label(voices, text='Giọng Edge').pack(side='left', padx=(0, 10))
        self.voice_box = ttk.Combobox(voices, textvariable=self.voice, state='disabled', values=['vi-VN-HoaiMyNeural', 'vi-VN-NamMinhNeural', 'en-US-JennyNeural', 'en-US-GuyNeural'])
        self.voice_box.pack(side='left', fill='x', expand=True)
        self.voices_button = ttk.Button(voices, text='Tải danh sách giọng', command=self.load_voices, state='disabled')
        self.voices_button.pack(side='left', padx=(10, 0))

        toolbar = ttk.Frame(frame)
        toolbar.pack(fill='x', pady=(0, 8))
        ttk.Label(toolbar, text='Nội dung', font=('Segoe UI', 11, 'bold')).pack(side='left')
        self.import_button = ttk.Button(toolbar, text='Import SRT / TXT', command=self.import_file)
        self.import_button.pack(side='right')
        self.editor = scrolledtext.ScrolledText(frame, wrap='word', font=('Segoe UI', 11), undo=True, height=14, padx=12, pady=12, relief='solid', bd=1)
        self.editor.pack(fill='both', expand=True)
        ttk.Label(frame, text='SRT: tự tăng tốc từng câu cho vừa mốc, kể cả trên 2x; giữ đủ lời. Câu quá dài sẽ đọc nhanh hơn.', style='Sub.TLabel', wraplength=870).pack(anchor='w', pady=(10, 4))
        ttk.Label(frame, text='Cần Internet. Nội dung được gửi tới Google hoặc Microsoft theo dịch vụ bạn chọn.', style='Sub.TLabel', wraplength=870).pack(anchor='w')
        self.bar = ttk.Progressbar(frame, maximum=100)
        self.bar.pack(fill='x', pady=(14, 6))
        ttk.Label(frame, textvariable=self.status, wraplength=870).pack(anchor='w')
        footer = ttk.Frame(frame)
        footer.pack(fill='x', pady=(14, 0))
        self.export_button = ttk.Button(footer, text='Xuất âm thanh…', command=self.start)
        self.export_button.pack(side='left')
        self.cancel_button = ttk.Button(footer, text='Hủy', command=self.cancel, state='disabled')
        self.cancel_button.pack(side='left', padx=8)
        self.open_button = ttk.Button(footer, text='Mở thư mục kết quả', command=self.open_output, state='disabled')
        self.open_button.pack(side='right')
        root.protocol('WM_DELETE_WINDOW', self.close)
        root.after(100, self.poll)

    def update_provider(self, event=None):
        edge = self.provider.get() == 'Edge TTS'
        self.lang_box.configure(state='disabled' if edge or self.busy else 'normal')
        self.voice_box.configure(state='readonly' if edge and not self.busy else 'disabled')
        self.voices_button.configure(state='normal' if edge and not self.busy else 'disabled')

    def import_file(self):
        path = filedialog.askopenfilename(filetypes=[('Văn bản / phụ đề', '*.srt *.txt'), ('Tất cả', '*.*')])
        if not path:
            return
        try:
            text = read_document(path)
            if Path(path).suffix.lower() == '.srt':
                cues = parse_srt(text)
                self.mode.set('SRT')
                self.status.set(f'Đã import {len(cues)} đoạn SRT: {Path(path).name}')
            else:
                self.mode.set('Văn bản')
                self.status.set(f'Đã import: {Path(path).name}')
            self.editor.delete('1.0', 'end')
            self.editor.insert('1.0', text)
        except Exception as exc:
            messagebox.showerror('Không import được', str(exc))

    def load_voices(self):
        self.voices_button.configure(state='disabled')
        self.status.set('Đang tải danh sách giọng Edge…')
        def work():
            try:
                import edge_tts
                voices = asyncio.run(asyncio.wait_for(edge_tts.list_voices(), timeout=30))
                names = sorted((v['ShortName'] for v in voices), key=lambda n: (not n.startswith('vi-'), n))
                self.events.put(('voices', names))
            except Exception as exc:
                self.events.put(('voice_error', str(exc)))
        threading.Thread(target=work, daemon=True).start()

    def set_busy(self, busy):
        self.busy = busy
        for widget in [self.export_button, self.import_button, self.speed_box]:
            widget.configure(state='disabled' if busy else 'normal')
        for widget in [self.provider_box, self.mode_box]:
            widget.configure(state='disabled' if busy else 'readonly')
        self.editor.configure(state='disabled' if busy else 'normal')
        self.cancel_button.configure(state='normal' if busy else 'disabled')
        self.update_provider()

    def start(self):
        if self.busy:
            return
        content = self.editor.get('1.0', 'end').strip()
        try:
            speed = float(self.speed.get().replace(',', '.'))
            if not .5 <= speed <= 2:
                raise ValueError('Tốc độ phải từ 0.5 đến 2.')
            if not content:
                raise ValueError('Hãy nhập văn bản hoặc import SRT.')
            # Detect pasted SRT rather than speaking timestamps accidentally.
            if self.mode.get() == 'Văn bản' and '-->' in content:
                if messagebox.askyesno('Nội dung SRT', 'Nội dung có mốc SRT. Chuyển sang chế độ SRT để giữ đúng thời gian?'):
                    self.mode.set('SRT')
                else:
                    return
            if self.mode.get() == 'SRT':
                parse_srt(content)
        except ValueError as exc:
            messagebox.showerror('Kiểm tra nội dung', str(exc))
            return
        output = filedialog.asksaveasfilename(defaultextension='.mp3', initialfile='giong-doc.mp3', filetypes=[('MP3', '*.mp3'), ('WAV', '*.wav')])
        if not output:
            return
        options = (content, self.mode.get(), self.provider.get(), self.language.get().strip(), self.voice.get().strip(), speed, output)
        self.cancelled.clear()
        self.bar['value'] = 0
        self.set_busy(True)
        def work():
            try:
                engine = Engine(self.cancelled, lambda value, text: self.events.put(('progress', (value, text))))
                issues = engine.export(*options)
                self.events.put(('done', (output, issues)))
            except Cancelled:
                self.events.put(('cancelled', None))
            except Exception as exc:
                self.events.put(('error', str(exc)))
        threading.Thread(target=work, daemon=True).start()

    def cancel(self):
        self.cancelled.set()
        self.cancel_button.configure(state='disabled')
        self.status.set('Đang hủy… Đợi yêu cầu online hiện tại kết thúc.')

    def poll(self):
        try:
            while True:
                kind, data = self.events.get_nowait()
                if kind == 'progress':
                    value, text = data
                    self.bar['value'] = value
                    if not self.cancelled.is_set():
                        self.status.set(text)
                elif kind == 'voices':
                    self.voice_box.configure(values=data)
                    self.update_provider()
                    if not self.busy:
                        self.status.set(f'Đã tải {len(data)} giọng Edge. Giọng Việt ở đầu danh sách.')
                elif kind == 'voice_error':
                    self.update_provider()
                    messagebox.showwarning('Danh sách giọng', 'Chưa tải được danh sách; vẫn có thể chọn giọng Việt có sẵn.\n' + data)
                else:
                    self.set_busy(False)
                    if kind == 'done':
                        output, issues = data
                        self.last_output = output
                        self.open_button.configure(state='normal')
                        self.status.set(f'Đã xuất: {output}')
                        if issues:
                            messagebox.showwarning('Đã xuất, có lỗi xử lý âm thanh', f'{len(issues)} đoạn gặp lỗi xử lý âm thanh.\nÂm thanh phục hồi được giữ trong thư mục “-doan-can-sua”.\nXem nguyên nhân trong .timeline.json cạnh file kết quả.')
                        else:
                            messagebox.showinfo('Hoàn tất', f'Đã xuất âm thanh:\n{output}')
                    elif kind == 'cancelled':
                        self.status.set('Đã hủy. File kết quả cũ được giữ nguyên.')
                    elif kind == 'error':
                        self.status.set('Chưa xuất được âm thanh.')
                        messagebox.showerror('Không xuất được', data)
        except queue.Empty:
            pass
        self.root.after(100, self.poll)

    def open_output(self):
        if self.last_output:
            os.startfile(str(Path(self.last_output).parent))

    def close(self):
        if self.busy:
            messagebox.showinfo('Tác vụ đang chạy', 'Bấm Hủy và đợi tác vụ dừng trước khi đóng ứng dụng.')
        else:
            self.root.destroy()


if __name__ == '__main__':
    if '--smoke-test' in sys.argv:
        import gtts
        import edge_tts
        import certifi
        import subprocess
        from core import ffmpeg_path
        root = tk.Tk()
        root.withdraw()
        app = App(root)
        root.update()
        subprocess.run([ffmpeg_path(), '-version'], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        root.destroy()
    else:
        root = tk.Tk()
        App(root)
        root.mainloop()
