"""Live service checks on GitHub; a transient service error does not block packaging."""
from pathlib import Path
import json
import tempfile
from core import Engine

results = {}
with tempfile.TemporaryDirectory() as tmp:
    for provider in ['gTTS', 'Edge TTS']:
        try:
            target = Path(tmp) / (provider + '.mp3')
            Engine().export('Xin chào. Đây là bản kiểm tra giọng đọc tiếng Việt.', 'Văn bản', provider,
                            'vi', 'vi-VN-HoaiMyNeural', 1, target)
            results[provider] = {'ok': True, 'audio_bytes': target.stat().st_size}
        except Exception as exc:
            results[provider] = {'ok': False, 'error': str(exc)}
Path('online-check.json').write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
print('ONLINE_CHECK=' + json.dumps(results, ensure_ascii=True), flush=True)
