import copy
import json
from pathlib import Path
import shutil
import tempfile
import threading
import unittest
from unittest.mock import patch
import wave

from core import Cancelled, Engine, parse_srt, read_document
from timeline import merge_timeline


SRT = '1\n00:00:00,500 --> 00:00:01,500\nXin chào\n\n2\n00:00:02,000 --> 00:00:03,000\nTiếng Việt &amp; <i>phụ đề</i>\n'


def tone(path, seconds=1):
    with wave.open(str(path), 'wb') as f:
        f.setparams((2, 2, 48000, 0, 'NONE', 'not compressed'))
        f.writeframes(b'\x00\x20\x00\x20' * round(seconds * 48000))


class ParsingTests(unittest.TestCase):
    def test_unicode_bom_and_html(self):
        cues = parse_srt('\ufeff' + SRT.replace('\n', '\r\n'))
        self.assertEqual((cues[0].start, cues[-1].end), (500, 3000))
        self.assertEqual(cues[1].text, 'Tiếng Việt & phụ đề')

    def test_multiline_and_fractional_timestamps(self):
        cue = parse_srt('00:00:01.5 --> 00:00:03.02\nMột\nhai')[0]
        self.assertEqual((cue.start, cue.end, cue.text), (1500, 3020, 'Một hai'))

    def test_bad_input_does_not_reach_online_service(self):
        for text in ['', 'Xin chào', '1\n00:00:02,000 --> 00:00:01,000\nA', SRT.replace('00:00:02,000', '00:00:01,000')]:
            with self.subTest(text=text), self.assertRaises(ValueError):
                parse_srt(text)

    def test_utf16_import(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'tiếng Việt.srt'
            path.write_bytes(SRT.encode('utf-16'))
            self.assertEqual(read_document(path), SRT)

    def test_timeline_does_not_mutate_cues_and_keeps_silence(self):
        with tempfile.TemporaryDirectory() as tmp:
            wav = Path(tmp) / 'voice.wav'
            tone(wav, .5)
            cues = [dict(line=1, start_time=500, end_time=1500, filename=str(wav), rate='+0%')]
            original = copy.deepcopy(cues)
            target = Path(tmp) / 'timeline.wav'
            issues, _ = merge_timeline(cues, target, tmp, lambda *a, **k: self.fail('No tempo needed'))
            self.assertEqual(cues, original)
            self.assertFalse(issues)
            with wave.open(str(target)) as audio:
                self.assertEqual(audio.getnframes(), 72000)
                self.assertEqual(audio.readframes(24000), b'\0' * 96000)
                self.assertNotEqual(audio.readframes(24000), b'\0' * 96000)

    def test_cancel_preserves_existing_output(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / 'out.mp3'
            target.write_bytes(b'existing')
            cancelled = threading.Event()
            cancelled.set()
            with self.assertRaises(Cancelled):
                Engine(cancelled).export('text', 'Văn bản', 'gTTS', 'vi', '', 1, target)
            self.assertEqual(target.read_bytes(), b'existing')
            self.assertEqual(list(Path(tmp).iterdir()), [target])

    def test_network_error_preserves_output_and_cleans_temporary_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / 'out.wav'
            target.write_bytes(b'existing')
            with patch.object(Engine, 'speak', side_effect=RuntimeError('network unavailable')):
                with self.assertRaisesRegex(RuntimeError, 'network unavailable'):
                    Engine().export('text', 'Văn bản', 'Edge TTS', 'vi', 'vi-VN-HoaiMyNeural', 1, target)
            self.assertEqual(target.read_bytes(), b'existing')
            self.assertEqual(list(Path(tmp).iterdir()), [target])


@unittest.skipUnless(shutil.which('ffmpeg') or (Path(__file__).parent / 'ffmpeg.exe').is_file(), 'FFmpeg integration runs on GitHub')
class AudioTests(unittest.TestCase):
    def synthesize(self, text, provider, language, voice, target):
        tone(target, .6 if text != 'LONG' else 3)

    def test_text_wav_and_mp3_with_real_ffmpeg(self):
        for suffix in ['.wav', '.mp3']:
            with self.subTest(suffix=suffix), tempfile.TemporaryDirectory() as tmp:
                target = Path(tmp) / ('âm thanh' + suffix)
                with patch.object(Engine, 'speak', self.synthesize):
                    issues = Engine().export('Xin chào', 'Văn bản', 'gTTS', 'vi', '', 1.3, target)
                self.assertFalse(issues)
                self.assertGreater(target.stat().st_size, 100)
                if suffix == '.wav':
                    with wave.open(str(target)) as f:
                        self.assertAlmostEqual(f.getnframes() / f.getframerate(), .6 / 1.3, delta=.03)

    def test_srt_exact_duration_and_silence(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / 'out.wav'
            with patch.object(Engine, 'speak', self.synthesize):
                issues = Engine().export(SRT, 'SRT', 'Edge TTS', 'vi', 'vi-VN-HoaiMyNeural', 1, target)
            self.assertFalse(issues)
            with wave.open(str(target)) as f:
                self.assertEqual(f.getnframes(), 3000 * 48)
                self.assertEqual(f.readframes(500 * 48), b'\0' * (500 * 48 * 4))

    def test_long_cue_above_2x_is_spoken_without_moving_next_cue(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / 'out.wav'
            with patch.object(Engine, 'speak', self.synthesize):
                issues = Engine().export(SRT.replace('Xin chào', 'LONG'), 'SRT', 'gTTS', 'vi', '', 1, target)
            self.assertFalse(issues)
            report = json.loads(target.with_suffix('.timeline.json').read_text(encoding='utf-8'))
            self.assertGreater(report['adjustments'][0]['speed'], 2)
            self.assertTrue(report['auto_fit'])
            self.assertIsNone(report['max_speed'])
            self.assertFalse((Path(tmp) / 'out-doan-can-sua').exists())
            with wave.open(str(target)) as f:
                self.assertEqual(f.getnframes(), 3000 * 48)
                f.setpos(500 * 48)
                self.assertNotEqual(f.readframes(600 * 48), b'\0' * (600 * 48 * 4))
                f.setpos(1500 * 48)
                self.assertEqual(f.readframes(500 * 48), b'\0' * (500 * 48 * 4))
                self.assertNotEqual(f.readframes(500 * 48), b'\0' * (500 * 48 * 4))

    def test_reported_line_4_window_accepts_audio_longer_than_2x(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / 'line4.wav'
            source = Path(tmp) / 'long.wav'
            tone(source, 4.8)
            queue = [dict(line=4, start_time=8400, end_time=10132,
                          filename=str(source), rate='+0%')]
            issues, path = merge_timeline(queue, target, tmp, Engine().ffmpeg)
            self.assertFalse(issues)
            report = json.loads(Path(path).read_text())
            self.assertGreater(report['adjustments'][0]['speed'], 2)
            with wave.open(str(target)) as f:
                self.assertEqual(f.getnframes(), 10132 * 48)
                f.setpos(8400 * 48)
                audio = f.readframes(1200 * 48)
                self.assertNotEqual(audio, b'\0' * len(audio))

    def test_auto_fit_can_chain_tempo_above_4x(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, target = Path(tmp) / 'long.wav', Path(tmp) / 'out.wav'
            tone(source, 4)
            cues = [dict(line=1, start_time=0, end_time=750, filename=str(source), rate='+0%')]
            issues, path = merge_timeline(cues, target, tmp, Engine().ffmpeg)
            self.assertFalse(issues)
            report = json.loads(Path(path).read_text())
            self.assertGreater(report['adjustments'][0]['speed'], 4)
            with wave.open(str(target)) as f:
                self.assertEqual(f.getnframes(), 750 * 48)
                self.assertNotEqual(f.readframes(20000), b'\0' * 80000)


if __name__ == '__main__':
    unittest.main()
