import copy
from pathlib import Path
import shutil
import tempfile
import threading
import unittest
from unittest.mock import patch
import wave

from core import Cancelled, Engine, parse_srt, read_document
from timeline import merge_timeline


SRT = '1\n00:00:00,500 --> 00:00:01,500\nXin chào\n\n2\n00:00:02,000 --> 00:00:03,000\nTiếng Việt &amp; <i>phụ đề</i>\n'


def tone(path, seconds=1):
    with wave.open(str(path), 'wb') as f:
        f.setparams((2, 2, 48000, 0, 'NONE', 'not compressed'))
        f.writeframes(b'\x00\x20\x00\x20' * round(seconds * 48000))


class ParsingTests(unittest.TestCase):
    def test_unicode_bom_and_html(self):
        cues = parse_srt('\ufeff' + SRT.replace('\n', '\r\n'))
        self.assertEqual((cues[0].start, cues[-1].end), (500, 3000))
        self.assertEqual(cues[1].text, 'Tiếng Việt & phụ đề')

    def test_multiline_and_fractional_timestamps(self):
        cue = parse_srt('00:00:01.5 --> 00:00:03.02\nMột\nhai')[0]
        self.assertEqual((cue.start, cue.end, cue.text), (1500, 3020, 'Một hai'))

    def test_bad_input_does_not_reach_online_service(self):
        for text in ['', 'Xin chào', '1\n00:00:02,000 --> 00:00:01,000\nA', SRT.replace('00:00:02,000', '00:00:01,000')]:
            with self.subTest(text=text), self.assertRaises(ValueError):
                parse_srt(text)

    def test_utf16_import(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'tiếng Việt.srt'
            path.write_bytes(SRT.encode('utf-16'))
            self.assertEqual(read_document(path), SRT)

    def test_timeline_does_not_mutate_cues_and_keeps_silence(self):
        with tempfile.TemporaryDirectory() as tmp:
            wav = Path(tmp) / 'voice.wav'
            tone(wav, .5)
            cues = [dict(line=1, start_time=500, end_time=1500, filename=str(wav), rate='+0%')]
            original = copy.deepcopy(cues)
            target = Path(tmp) / 'timeline.wav'
            issues, _ = merge_timeline(cues, target, tmp, lambda *a, **k: self.fail('No tempo needed'))
            self.assertEqual(cues, original)
            self.assertFalse(issues)
            with wave.open(str(target)) as audio:
                self.assertEqual(audio.getnframes(), 72000)
                self.assertEqual(audio.readframes(24000), b'\0' * 96000)
                self.assertNotEqual(audio.readframes(24000), b'\0' * 96000)

    def test_cancel_preserves_existing_output(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / 'out.mp3'
            target.write_bytes(b'existing')
            cancelled = threading.Event()
            cancelled.set()
            with self.assertRaises(Cancelled):
                Engine(cancelled).export('text', 'Văn bản', 'gTTS', 'vi', '', 1, target)
            self.assertEqual(target.read_bytes(), b'existing')
            self.assertEqual(list(Path(tmp).iterdir()), [target])

    def test_network_error_preserves_output_and_cleans_temporary_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / 'out.wav'
            target.write_bytes(b'existing')
            with patch.object(Engine, 'speak', side_effect=RuntimeError('network unavailable')):
                with self.assertRaisesRegex(RuntimeError, 'network unavailable'):
                    Engine().export('text', 'Văn bản', 'Edge TTS', 'vi', 'vi-VN-HoaiMyNeural', 1, target)
            self.assertEqual(target.read_bytes(), b'existing')
            self.assertEqual(list(Path(tmp).iterdir()), [target])


@unittest.skipUnless(shutil.which('ffmpeg') or (Path(__file__).parent / 'ffmpeg.exe').is_file(), 'FFmpeg integration runs on GitHub')
class AudioTests(unittest.TestCase):
    def synthesize(self, text, provider, language, voice, target):
        tone(target, .6 if text != 'LONG' else 3)

    def test_text_wav_and_mp3_with_real_ffmpeg(self):
        for suffix in ['.wav', '.mp3']:
            with self.subTest(suffix=suffix), tempfile.TemporaryDirectory() as tmp:
                target = Path(tmp) / ('âm thanh' + suffix)
                with patch.object(Engine, 'speak', self.synthesize):
                    issues = Engine().export('Xin chào', 'Văn bản', 'gTTS', 'vi', '', 1.3, target)
                self.assertFalse(issues)
                self.assertGreater(target.stat().st_size, 100)
                if suffix == '.wav':
                    with wave.open(str(target)) as f:
                        self.assertAlmostEqual(f.getnframes() / f.getframerate(), .6 / 1.3, delta=.03)

    def test_srt_exact_duration_and_silence(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / 'out.wav'
            with patch.object(Engine, 'speak', self.synthesize):
                issues = Engine().export(SRT, 'SRT', 'Edge TTS', 'vi', 'vi-VN-HoaiMyNeural', 1, target)
            self.assertFalse(issues)
            with wave.open(str(target)) as f:
                self.assertEqual(f.getnframes(), 3000 * 48)
                self.assertEqual(f.readframes(500 * 48), b'\0' * (500 * 48 * 4))

    def test_unfittable_cue_keeps_recovery_audio(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / 'out.wav'
            with patch.object(Engine, 'speak', self.synthesize):
                issues = Engine().export(SRT.replace('Xin chào', 'LONG'), 'SRT', 'gTTS', 'vi', '', 1, target)
            self.assertEqual(len(issues), 1)
            self.assertEqual(issues[0]['reason'], 'required_speed_exceeds_2x')
            self.assertTrue(Path(issues[0]['audio']).is_file())
            self.assertTrue(target.with_suffix('.timeline.json').is_file())


if __name__ == '__main__':
    unittest.main()
