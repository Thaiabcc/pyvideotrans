import copy
import json
from pathlib import Path
import shutil
import tempfile
import threading
import struct
import unittest
from unittest.mock import patch
import wave

from core import Cancelled, Engine, parse_srt, read_document, split_text
from pcm import Reader, Writer, header
from timeline import merge_timeline


SRT = '1\n00:00:00,500 --> 00:00:01,500\nXin chào\n\n2\n00:00:02,000 --> 00:00:03,000\nTiếng Việt &amp; <i>phụ đề</i>\n'


def tone(path, seconds=1):
    with wave.open(str(path), 'wb') as f:
        f.setparams((2, 2, 48000, 0, 'NONE', 'not compressed'))
        f.writeframes(b'\x00\x20\x00\x20' * round(seconds * 48000))


class ParsingTests(unittest.TestCase):
    def test_unicode_bom_and_html(self):
        cues = parse_srt('\ufeff' + SRT.replace('\n', '\r\n'))
        self.assertEqual((cues[0].start, cues[-1].end), (500, 3000))
        self.assertEqual(cues[1].text, 'Tiếng Việt & phụ đề')

    def test_multiline_and_fractional_timestamps(self):
        cue = parse_srt('00:00:01.5 --> 00:00:03.02\nMột\nhai')[0]
        self.assertEqual((cue.start, cue.end, cue.text), (1500, 3020, 'Một hai'))

    def test_bad_input_does_not_reach_online_service(self):
        for text in ['', 'Xin chào', '1\n00:00:02,000 --> 00:00:01,000\nA', SRT.replace('00:00:02,000', '00:00:01,000')]:
            with self.subTest(text=text), self.assertRaises(ValueError):
                parse_srt(text)

    def test_utf16_import(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'tiếng Việt.srt'
            path.write_bytes(SRT.encode('utf-16'))
            self.assertEqual(read_document(path), SRT)

    def test_timeline_does_not_mutate_cues_and_keeps_silence(self):
        with tempfile.TemporaryDirectory() as tmp:
            wav = Path(tmp) / 'voice.wav'
            tone(wav, .5)
            cues = [dict(line=1, start_time=500, end_time=1500, filename=str(wav), rate='+0%')]
            original = copy.deepcopy(cues)
            target = Path(tmp) / 'timeline.wav'
            issues, _ = merge_timeline(cues, target, tmp, lambda *a, **k: self.fail('No tempo needed'))
            self.assertEqual(cues, original)
            self.assertFalse(issues)
            with wave.open(str(target)) as audio:
                self.assertEqual(audio.getnframes(), 72000)
                self.assertEqual(audio.readframes(24000), b'\0' * 96000)
                self.assertNotEqual(audio.readframes(24000), b'\0' * 96000)

    def test_cancel_preserves_existing_output(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / 'out.mp3'
            target.write_bytes(b'existing')
            cancelled = threading.Event()
            cancelled.set()
            with self.assertRaises(Cancelled):
                Engine(cancelled).export('text', 'Văn bản', 'gTTS', 'vi', '', 1, target)
            self.assertEqual(target.read_bytes(), b'existing')
            self.assertFalse(list(Path(tmp).glob('tts-lite-*')))

    def test_network_error_preserves_output_and_cleans_temporary_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / 'out.wav'
            target.write_bytes(b'existing')
            with patch.object(Engine, 'speak', side_effect=RuntimeError('network unavailable')):
                with self.assertRaisesRegex(RuntimeError, 'network unavailable'):
                    Engine().export('text', 'Văn bản', 'Edge TTS', 'vi', 'vi-VN-HoaiMyNeural', 1, target)
            self.assertEqual(target.read_bytes(), b'existing')
            self.assertTrue((Path(tmp) / '.tts-lite-cache').is_dir())
            self.assertFalse(list(Path(tmp).glob('tts-lite-*')))
            self.assertFalse(list(Path(tmp).rglob('*.part.*')))

    def test_text_chunks_preserve_words_and_bound_network_requests(self):
        text = ('Tiếng Việt có dấu và nội dung dài.\n' * 300)
        chunks = split_text(text)
        self.assertTrue(all(0 < len(chunk) <= 1200 for chunk in chunks))
        self.assertEqual(' '.join(' '.join(chunks).split()), ' '.join(text.split()))
        self.assertEqual(''.join(split_text('字' * 5001)), '字' * 5001)

    def test_rf64_header_can_describe_more_than_four_gib(self):
        frames = 2**31
        raw = header(frames)
        self.assertEqual(raw[:4], b'RF64')
        self.assertEqual(struct.unpack_from('<Q', raw, 28)[0], frames * 4)
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / 'small-rf64.wav'
            with Writer(target, 3, force_rf64=True) as writer:
                writer.writeframesraw(b'\x01\0\x02\0' * 3)
            with Reader(target) as reader:
                self.assertEqual(reader.getnframes(), 3)
                self.assertEqual(reader.readframes(99), b'\x01\0\x02\0' * 3)

    def test_corrupt_cache_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / 'bad.wav'
            target.write_bytes(header(1000) + b'\0' * 8)
            with self.assertRaisesRegex(ValueError, 'truncated_wave_audio'):
                Reader(target)

    def test_many_cues_keep_exact_timeline(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, target = Path(tmp) / 'voice.wav', Path(tmp) / 'many.wav'
            tone(source, .001)
            cues = [dict(line=i+1, start_time=i*4, end_time=i*4+2,
                         filename=str(source), rate='+0%') for i in range(5000)]
            issues, _ = merge_timeline(cues, target, tmp, lambda *a, **k: self.fail('No tempo needed'))
            self.assertFalse(issues)
            with Reader(target) as f:
                self.assertEqual(f.getnframes(), (4999 * 4 + 2) * 48)


@unittest.skipUnless(shutil.which('ffmpeg') or (Path(__file__).parent / 'ffmpeg.exe').is_file(), 'FFmpeg integration runs on GitHub')
class AudioTests(unittest.TestCase):
    def synthesize(self, text, provider, language, voice, target):
        tone(target, .6 if text != 'LONG' else 3)

    def test_text_wav_and_mp3_with_real_ffmpeg(self):
        for suffix in ['.wav', '.mp3']:
            with self.subTest(suffix=suffix), tempfile.TemporaryDirectory() as tmp:
                target = Path(tmp) / ('âm thanh' + suffix)
                with patch.object(Engine, 'speak', self.synthesize):
                    issues = Engine().export('Xin chào', 'Văn bản', 'gTTS', 'vi', '', 1.3, target)
                self.assertFalse(issues)
                self.assertGreater(target.stat().st_size, 100)
                if suffix == '.wav':
                    with wave.open(str(target)) as f:
                        self.assertAlmostEqual(f.getnframes() / f.getframerate(), .6 / 1.3, delta=.03)

    def test_srt_exact_duration_and_silence(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / 'out.wav'
            with patch.object(Engine, 'speak', self.synthesize):
                issues = Engine().export(SRT, 'SRT', 'Edge TTS', 'vi', 'vi-VN-HoaiMyNeural', 1, target)
            self.assertFalse(issues)
            with wave.open(str(target)) as f:
                self.assertEqual(f.getnframes(), 3000 * 48)
                self.assertEqual(f.readframes(500 * 48), b'\0' * (500 * 48 * 4))

    def test_long_cue_above_2x_is_spoken_without_moving_next_cue(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / 'out.wav'
            with patch.object(Engine, 'speak', self.synthesize):
                issues = Engine().export(SRT.replace('Xin chào', 'LONG'), 'SRT', 'gTTS', 'vi', '', 1, target)
            self.assertFalse(issues)
            report = json.loads(target.with_suffix('.timeline.json').read_text(encoding='utf-8'))
            self.assertGreater(report['adjustments'][0]['speed'], 2)
            self.assertTrue(report['auto_fit'])
            self.assertIsNone(report['max_speed'])
            self.assertFalse((Path(tmp) / 'out-doan-can-sua').exists())
            with wave.open(str(target)) as f:
                self.assertEqual(f.getnframes(), 3000 * 48)
                f.setpos(500 * 48)
                self.assertNotEqual(f.readframes(600 * 48), b'\0' * (600 * 48 * 4))
                f.setpos(1500 * 48)
                self.assertEqual(f.readframes(500 * 48), b'\0' * (500 * 48 * 4))
                self.assertNotEqual(f.readframes(500 * 48), b'\0' * (500 * 48 * 4))

    def test_reported_line_4_window_accepts_audio_longer_than_2x(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / 'line4.wav'
            source = Path(tmp) / 'long.wav'
            tone(source, 4.8)
            queue = [dict(line=4, start_time=8400, end_time=10132,
                          filename=str(source), rate='+0%')]
            issues, path = merge_timeline(queue, target, tmp, Engine().ffmpeg)
            self.assertFalse(issues)
            report = json.loads(Path(path).read_text())
            self.assertGreater(report['adjustments'][0]['speed'], 2)
            with wave.open(str(target)) as f:
                self.assertEqual(f.getnframes(), 10132 * 48)
                f.setpos(8400 * 48)
                audio = f.readframes(1200 * 48)
                self.assertNotEqual(audio, b'\0' * len(audio))

    def test_auto_fit_can_chain_tempo_above_4x(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, target = Path(tmp) / 'long.wav', Path(tmp) / 'out.wav'
            tone(source, 4)
            cues = [dict(line=1, start_time=0, end_time=750, filename=str(source), rate='+0%')]
            issues, path = merge_timeline(cues, target, tmp, Engine().ffmpeg)
            self.assertFalse(issues)
            report = json.loads(Path(path).read_text())
            self.assertGreater(report['adjustments'][0]['speed'], 4)
            with wave.open(str(target)) as f:
                self.assertEqual(f.getnframes(), 750 * 48)
                self.assertNotEqual(f.readframes(20000), b'\0' * 80000)

    def test_resume_after_network_error_reuses_completed_clips(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / 'out.wav'
            original = b'previous-output'
            target.write_bytes(original)
            calls = []
            def interrupted(text, provider, language, voice, path):
                calls.append(text)
                if len(calls) == 2:
                    raise RuntimeError('network down')
                tone(path, .5)
            with patch.object(Engine, 'speak', side_effect=interrupted):
                with self.assertRaisesRegex(RuntimeError, 'network down'):
                    Engine().export(SRT, 'SRT', 'gTTS', 'vi', '', 1, target)
            self.assertEqual(target.read_bytes(), original)
            self.assertTrue(list(Path(tmp).rglob('*.wav')))
            with patch.object(Engine, 'speak', side_effect=self.synthesize) as resume:
                Engine().export(SRT, 'SRT', 'gTTS', 'vi', '', 1, target)
            self.assertEqual(resume.call_count, 1)
            self.assertFalse(list((Path(tmp) / '.tts-lite-cache').iterdir()))

    def test_render_error_never_publishes_missing_speech(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / 'out.wav'
            target.write_bytes(b'existing')
            def fail_merge(queue, *args):
                report = Path(tmp) / 'error.json'
                report.write_text(json.dumps({'issues': [{'line': 1, 'reason': 'conversion_failed'}]}))
                return [{'line': 1, 'reason': 'conversion_failed'}], str(report)
            with patch.object(Engine, 'speak', self.synthesize), patch('core.merge_timeline', fail_merge):
                with self.assertRaisesRegex(RuntimeError, 'Chưa xuất file'):
                    Engine().export(SRT, 'SRT', 'gTTS', 'vi', '', 1, target)
            self.assertEqual(target.read_bytes(), b'existing')

    def test_rf64_audio_is_readable_by_ffmpeg(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, target = Path(tmp) / 'rf64.wav', Path(tmp) / 'out.mp3'
            with Writer(source, 48000, force_rf64=True) as out:
                out.writeframesraw(b'\0\x20\0\x20' * 48000)
            Engine().ffmpeg(['-y', '-i', source, '-c:a', 'libmp3lame', target])
            self.assertGreater(target.stat().st_size, 1000)

    def test_long_plain_text_is_split_and_joined(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / 'long.wav'
            content = ('Nội dung dài cần chia nhỏ. ' * 160)
            with patch.object(Engine, 'speak', side_effect=self.synthesize) as speaker:
                Engine().export(content, 'Văn bản', 'gTTS', 'vi', '', 1, target)
            count = len(split_text(content))
            self.assertEqual(speaker.call_count, len(set(split_text(content))))
            with Reader(target) as reader:
                self.assertEqual(reader.getnframes(), count * round(.6 * 48000))


if __name__ == '__main__':
    unittest.main()
