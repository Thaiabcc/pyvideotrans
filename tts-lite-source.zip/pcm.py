"""Streaming PCM WAV/RF64 access; RF64 supports audio beyond the 4 GiB RIFF limit."""
import struct


def header(frames, force_rf64=False):
    size = frames * 4
    fmt = struct.pack('<4sIHHIIHH', b'fmt ', 16, 1, 2, 48000, 192000, 4, 16)
    if size + 36 <= 0xFFFFFFFF and not force_rf64:
        return struct.pack('<4sI4s', b'RIFF', size + 36, b'WAVE') + fmt + struct.pack('<4sI', b'data', size)
    return (b'RF64\xff\xff\xff\xffWAVE' + struct.pack('<4sIQQQI', b'ds64', 28, size + 72, size, frames, 0)
            + fmt + b'data\xff\xff\xff\xff')


class Reader:
    def __init__(self, path):
        self.file = open(path, 'rb')
        try:
            first = self.file.read(12)
            if len(first) != 12 or first[:4] not in (b'RIFF', b'RF64') or first[8:] != b'WAVE':
                raise ValueError('invalid_pcm_wave')
            data64 = None
            valid_format = False
            while True:
                chunk = self.file.read(8)
                if len(chunk) != 8:
                    raise ValueError('missing_wave_data')
                name, size = struct.unpack('<4sI', chunk)
                if name == b'ds64':
                    if size < 28 or size > 1024 * 1024:
                        raise ValueError('invalid_rf64_header')
                    raw = self.file.read(size)
                    if len(raw) != size:
                        raise ValueError('truncated_rf64_header')
                    data64 = struct.unpack_from('<Q', raw, 8)[0]
                elif name == b'fmt ':
                    if size < 16 or size > 65536:
                        raise ValueError('invalid_wave_format')
                    raw = self.file.read(size)
                    code, channels, rate, _, align, bits = struct.unpack_from('<HHIIHH', raw)
                    pcm = code == 1 or (code == 65534 and len(raw) >= 40 and raw[24:40] == b'\x01\0\0\0\0\0\x10\0\x80\0\0\xaa\0\x38\x9b\x71')
                    valid_format = pcm and (channels, rate, align, bits) == (2, 48000, 4, 16)
                elif name == b'data':
                    if not valid_format:
                        raise ValueError('unexpected_audio_format')
                    if size == 0xFFFFFFFF:
                        if data64 is None:
                            raise ValueError('missing_rf64_size')
                        size = data64
                    self.start = self.file.tell()
                    self.file.seek(0, 2)
                    if size % 4 or self.file.tell() < self.start + size:
                        raise ValueError('truncated_wave_audio')
                    self.frames = size // 4
                    self.position = 0
                    self.file.seek(self.start)
                    break
                else:
                    self.file.seek(size, 1)
                if size % 2:
                    self.file.seek(1, 1)
        except BaseException:
            self.file.close()
            raise

    def getnframes(self): return self.frames
    def getnchannels(self): return 2
    def getsampwidth(self): return 2
    def getframerate(self): return 48000

    def readframes(self, count):
        count = min(count, self.frames - self.position)
        data = self.file.read(count * 4)
        if len(data) != count * 4:
            raise ValueError('truncated_wave_audio')
        self.position += count
        return data

    def setpos(self, position):
        if not 0 <= position <= self.frames:
            raise ValueError('invalid_wave_position')
        self.position = position
        self.file.seek(self.start + position * 4)

    def __enter__(self): return self
    def __exit__(self, *args): self.file.close()


class Writer:
    def __init__(self, path, frames, force_rf64=False):
        self.file = open(path, 'wb')
        self.expected = frames * 4
        self.written = 0
        self.file.write(header(frames, force_rf64))

    def writeframesraw(self, data):
        if len(data) % 4 or self.written + len(data) > self.expected:
            raise ValueError('wave_length_overflow')
        self.file.write(data)
        self.written += len(data)

    def __enter__(self): return self
    def __exit__(self, kind, value, tb):
        self.file.close()
        if kind is None and self.written != self.expected:
            raise ValueError('incomplete_wave_output')
