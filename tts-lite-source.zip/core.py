"""Online TTS and SRT export, without ML frameworks or local models."""
import asyncio
from dataclasses import dataclass
import html
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import wave

from timeline import merge_timeline, tempo_wav


class Cancelled(Exception):
    pass


@dataclass(frozen=True)
class Cue:
    number: int
    start: int
    end: int
    text: str


STAMP = r'(\d{1,}):([0-5]\d):([0-5]\d)[,.](\d{1,3})'
TIMING = re.compile(r'^\s*' + STAMP + r'\s*-->\s*' + STAMP + r'(?:\s+.*)?$')


def milliseconds(parts):
    h, m, s, fraction = parts
    return ((int(h) * 60 + int(m)) * 60 + int(s)) * 1000 + int(fraction.ljust(3, '0'))


def parse_srt(text):
    text = text.lstrip('\ufeff').replace('\r\n', '\n').replace('\r', '\n').strip()
    cues = []
    for block in re.split(r'\n[ \t]*\n', text):
        lines = block.strip().splitlines()
        if not lines:
            continue
        number = int(lines.pop(0)) if lines[0].strip().isdigit() else len(cues) + 1
        match = TIMING.fullmatch(lines[0]) if lines else None
        if not match:
            raise ValueError(f'SRT không hợp lệ tại đoạn {number}: thiếu mốc thời gian.')
        start, end = milliseconds(match.groups()[:4]), milliseconds(match.groups()[4:])
        content = html.unescape(re.sub(r'<[^>]+>', '', ' '.join(lines[1:]))).strip()
        if end <= start or not content:
            raise ValueError(f'SRT đoạn {number}: thời gian hoặc nội dung không hợp lệ.')
        if cues and start < cues[-1].end:
            raise ValueError(f'SRT đoạn {number} chồng thời gian với đoạn trước. Hãy sửa mốc SRT trước khi xuất.')
        cues.append(Cue(number, start, end, content))
    if not cues:
        raise ValueError('Chưa có đoạn phụ đề SRT nào.')
    return cues


def read_document(path):
    raw = Path(path).read_bytes()
    encodings = ('utf-16',) if raw.startswith((b'\xff\xfe', b'\xfe\xff')) else ('utf-8-sig', 'cp1258')
    for encoding in encodings:
        try:
            return raw.decode(encoding)
        except UnicodeError:
            continue
    raise ValueError('Không đọc được mã hóa file. Hãy lưu file dưới dạng UTF-8.')


def ffmpeg_path():
    folder = Path(getattr(sys, '_MEIPASS', Path(__file__).parent))
    bundled = folder / 'ffmpeg.exe'
    if bundled.is_file():
        return str(bundled)
    return shutil.which('ffmpeg') or 'ffmpeg'


class Engine:
    def __init__(self, cancelled=None, progress=lambda *args: None):
        self.cancelled = cancelled or threading.Event()
        self.progress = progress

    def check(self):
        if self.cancelled.is_set():
            raise Cancelled('Đã hủy tác vụ.')

    def ffmpeg(self, args, **kwargs):
        self.check()
        # Keep FFmpeg messages on disk: avoid pipe deadlocks on long jobs.
        with tempfile.TemporaryFile() as log:
            process = subprocess.Popen([ffmpeg_path(), '-nostdin', '-hide_banner', '-loglevel', 'error', *map(str, args)],
                                       stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=log,
                                       creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            while process.poll() is None:
                if self.cancelled.wait(.1):
                    process.terminate()
                    try:
                        process.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait()
                    raise Cancelled('Đã hủy tác vụ.')
            if process.returncode:
                log.seek(0)
                raise RuntimeError(log.read().decode('utf-8', errors='replace')[-2500:] or 'FFmpeg không xử lý được âm thanh.')

    async def edge(self, text, voice, destination):
        import edge_tts
        communicate = edge_tts.Communicate(text, voice, connect_timeout=10, receive_timeout=60)
        with open(destination, 'wb') as output:
            async for chunk in communicate.stream():
                self.check()
                if chunk['type'] == 'audio':
                    output.write(chunk['data'])

    def speak(self, text, provider, language, voice, destination):
        self.check()
        from gtts import gTTS
        for attempt in range(3):
            self.check()
            try:
                if provider == 'gTTS':
                    gTTS(text, lang=language, lang_check=True, timeout=(10, 60)).save(str(destination))
                else:
                    asyncio.run(self.edge(text, voice, destination))
                self.check()
                if not destination.is_file() or destination.stat().st_size == 0:
                    raise RuntimeError('Dịch vụ không trả về âm thanh.')
                return
            except Cancelled:
                raise
            except Exception:
                if attempt == 2:
                    raise
                self.progress(0, f'Kết nối bị gián đoạn, thử lại lần {attempt + 2}/3…')
                if self.cancelled.wait(2 * (attempt + 1)):
                    self.check()

    def export(self, content, mode, provider, language, voice, speed, destination):
        self.check()
        destination = Path(destination)
        if destination.suffix.lower() not in ('.mp3', '.wav'):
            raise ValueError('Chọn định dạng .mp3 hoặc .wav.')
        if not .5 <= speed <= 2:
            raise ValueError('Tốc độ phải từ 0,5x đến 2x.')
        cues = parse_srt(content) if mode == 'SRT' else []
        if not content.strip():
            raise ValueError('Hãy nhập văn bản trước.')
        # Temporary files share the destination volume for atomic final publication.
        with tempfile.TemporaryDirectory(prefix='tts-lite-', dir=destination.parent) as work:
            work = Path(work)
            final_wav = work / 'result.wav'
            issues = []
            if mode == 'SRT':
                queue = []
                for index, cue in enumerate(cues):
                    self.check()
                    self.progress(index * 85 / len(cues), f'{provider}: đoạn {index + 1}/{len(cues)}')
                    raw = work / f'{index}.mp3'
                    wav = work / f'{index}.wav'
                    self.speak(cue.text, provider, language, voice, raw)
                    tempo_wav(raw, wav, speed, self.ffmpeg)
                    queue.append(dict(line=cue.number, start_time=cue.start, end_time=cue.end,
                                      filename=str(wav), rate=f'{(speed - 1) * 100:+g}%'))
                self.progress(88, 'Đang căn âm thanh vào mốc SRT…')
                issues, report = merge_timeline(queue, final_wav, work, self.ffmpeg, self.cancelled.is_set)
                self.check()
                if issues:
                    # Keep the source speech for any cue that cannot fit within 2x.
                    recovery = destination.parent / (destination.stem + '-doan-can-sua')
                    recovery.mkdir(exist_ok=True)
                    for issue in issues:
                        source = Path(issue.get('audio') or '')
                        if source.is_file():
                            saved = recovery / f'doan-{issue["line"]}.wav'
                            shutil.copy2(source, saved)
                            issue['audio'] = str(saved)
                    report_file = destination.with_suffix('.timeline.json')
                    report_file.write_text(json.dumps({'issues': issues, 'max_speed': 2}, ensure_ascii=False, indent=2), encoding='utf-8')
            else:
                self.progress(10, f'{provider}: đang tạo giọng đọc…')
                raw = work / 'text.mp3'
                self.speak(content, provider, language, voice, raw)
                tempo_wav(raw, final_wav, speed, self.ffmpeg)
            self.check()
            self.progress(95, 'Đang xuất file âm thanh…')
            if destination.suffix.lower() == '.mp3':
                final = work / 'final.mp3'
                self.ffmpeg(['-y', '-i', final_wav, '-c:a', 'libmp3lame', '-b:a', '192k', final])
            else:
                final = final_wav
            self.check()
            os.replace(final, destination)
            self.progress(100, 'Đã xuất âm thanh.')
            return issues
