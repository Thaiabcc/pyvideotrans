"""Online TTS and SRT export, without ML frameworks or local models."""
import asyncio
from dataclasses import dataclass
import html
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import wave

from timeline import merge_timeline, tempo_wav
from pcm import Reader, Writer


class Cancelled(Exception):
    pass


@dataclass(frozen=True)
class Cue:
    number: int
    start: int
    end: int
    text: str


STAMP = r'(\d{1,}):([0-5]\d):([0-5]\d)[,.](\d{1,3})'
TIMING = re.compile(r'^\s*' + STAMP + r'\s*-->\s*' + STAMP + r'(?:\s+.*)?$')


def milliseconds(parts):
    h, m, s, fraction = parts
    return ((int(h) * 60 + int(m)) * 60 + int(s)) * 1000 + int(fraction.ljust(3, '0'))


def parse_srt(text):
    text = text.lstrip('\ufeff').replace('\r\n', '\n').replace('\r', '\n').strip()
    cues = []
    for block in re.split(r'\n[ \t]*\n', text):
        lines = block.strip().splitlines()
        if not lines:
            continue
        number = int(lines.pop(0)) if lines[0].strip().isdigit() else len(cues) + 1
        match = TIMING.fullmatch(lines[0]) if lines else None
        if not match:
            raise ValueError(f'SRT không hợp lệ tại đoạn {number}: thiếu mốc thời gian.')
        start, end = milliseconds(match.groups()[:4]), milliseconds(match.groups()[4:])
        content = html.unescape(re.sub(r'<[^>]+>', '', ' '.join(lines[1:]))).strip()
        if end <= start or not content:
            raise ValueError(f'SRT đoạn {number}: thời gian hoặc nội dung không hợp lệ.')
        if cues and start < cues[-1].end:
            raise ValueError(f'SRT đoạn {number} chồng thời gian với đoạn trước. Hãy sửa mốc SRT trước khi xuất.')
        cues.append(Cue(number, start, end, content))
    if not cues:
        raise ValueError('Chưa có đoạn phụ đề SRT nào.')
    return cues


def read_document(path):
    raw = Path(path).read_bytes()
    encodings = ('utf-16',) if raw.startswith((b'\xff\xfe', b'\xfe\xff')) else ('utf-8-sig', 'cp1258')
    for encoding in encodings:
        try:
            return raw.decode(encoding)
        except UnicodeError:
            continue
    raise ValueError('Không đọc được mã hóa file. Hãy lưu file dưới dạng UTF-8.')


def split_text(text, limit=1200):
    """Bound each network job without dropping words or splitting Unicode bytes."""
    text = text.strip()
    result = []
    position = 0
    while position < len(text):
        end = min(position + limit, len(text))
        cut = end
        if end < len(text):
            boundary = max(text.rfind('\n', position, end + 1), text.rfind(' ', position, end + 1))
            if boundary >= position + limit // 2:
                cut = boundary
        part = text[position:cut].strip()
        if part:
            result.append(part)
        position = cut
        while position < len(text) and text[position].isspace():
            position += 1
    return result


def ffmpeg_path():
    folder = Path(getattr(sys, '_MEIPASS', Path(__file__).parent))
    bundled = folder / 'ffmpeg.exe'
    if bundled.is_file():
        return str(bundled)
    return shutil.which('ffmpeg') or 'ffmpeg'


class Engine:
    def __init__(self, cancelled=None, progress=lambda *args: None):
        self.cancelled = cancelled or threading.Event()
        self.progress = progress

    def check(self):
        if self.cancelled.is_set():
            raise Cancelled('Đã hủy tác vụ.')

    def ffmpeg(self, args, **kwargs):
        self.check()
        # Keep FFmpeg messages on disk: avoid pipe deadlocks on long jobs.
        with tempfile.TemporaryFile() as log:
            started = time.monotonic()
            timeout = 180
            if '-i' in args:
                source = Path(args[args.index('-i') + 1])
                if source.is_file():
                    timeout = max(180, source.stat().st_size / 48000 + 120)
            process = subprocess.Popen([ffmpeg_path(), '-nostdin', '-hide_banner', '-loglevel', 'error', *map(str, args)],
                                       stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=log,
                                       creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            while process.poll() is None:
                if self.cancelled.wait(.1):
                    process.terminate()
                    try:
                        process.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait()
                    raise Cancelled('Đã hủy tác vụ.')
                if time.monotonic() - started > timeout:
                    process.kill()
                    process.wait()
                    raise RuntimeError('FFmpeg không phản hồi trong thời gian cho phép. Tiến độ TTS đã được giữ để chạy lại.')
            if process.returncode:
                log.seek(0, 2)
                log.seek(max(0, log.tell() - 2500))
                raise RuntimeError(log.read().decode('utf-8', errors='replace')[-2500:] or 'FFmpeg không xử lý được âm thanh.')

    async def edge(self, text, voice, destination):
        import edge_tts
        communicate = edge_tts.Communicate(text, voice, connect_timeout=10, receive_timeout=60)
        with open(destination, 'wb') as output:
            async for chunk in communicate.stream():
                self.check()
                if chunk['type'] == 'audio':
                    output.write(chunk['data'])

    def speak(self, text, provider, language, voice, destination):
        self.check()
        from gtts import gTTS
        for attempt in range(3):
            self.check()
            try:
                if provider == 'gTTS':
                    # Stream requests so Cancel can stop between Google's response chunks.
                    with open(destination, 'wb') as out:
                        for data in gTTS(text, lang=language, lang_check=True, timeout=(10, 30)).stream():
                            self.check()
                            out.write(data)
                else:
                    asyncio.run(asyncio.wait_for(self.edge(text, voice, destination), timeout=120))
                self.check()
                if not destination.is_file() or destination.stat().st_size == 0:
                    raise RuntimeError('Dịch vụ không trả về âm thanh.')
                return
            except Cancelled:
                raise
            except Exception:
                if attempt == 2:
                    raise
                self.progress(0, f'Kết nối bị gián đoạn, thử lại lần {attempt + 2}/3…')
                if self.cancelled.wait(2 * (attempt + 1)):
                    self.check()

    def join(self, files, target):
        total = 0
        for path in files:
            with Reader(path) as audio:
                total += audio.getnframes()
        with Writer(target, total) as output:
            for path in files:
                with Reader(path) as audio:
                    while True:
                        self.check()
                        data = audio.readframes(48000)
                        if not data:
                            break
                        output.writeframesraw(data)

    def clip(self, text, provider, language, voice, speed, cache):
        key = hashlib.sha256(json.dumps([text, provider, language, voice, speed], ensure_ascii=False).encode('utf-8')).hexdigest()
        wav = cache / (key + '.wav')
        if wav.exists():
            try:
                with Reader(wav) as audio:
                    if audio.getnframes() > 0:
                        return wav
            except (OSError, ValueError):
                pass
        raw = cache / (key + '.mp3')
        part = cache / (key + '.part.mp3')
        converted = cache / (key + '.part.wav')
        try:
            for attempt in range(2):
                self.check()
                if not raw.is_file() or raw.stat().st_size == 0:
                    self.speak(text, provider, language, voice, part)
                    self.check()
                    os.replace(part, raw)
                try:
                    tempo_wav(raw, converted, speed, self.ffmpeg)
                    self.check()
                    os.replace(converted, wav)
                    return wav
                except Cancelled:
                    raise
                except Exception:
                    # A corrupted cached download must be fetched again, never reused forever.
                    raw.unlink(missing_ok=True)
                    if attempt:
                        raise
        finally:
            part.unlink(missing_ok=True)
            converted.unlink(missing_ok=True)

    def disk_space(self, folder, frames, mp3):
        needed = frames * 4 + (frames // 2 if mp3 else 0) + 32 * 1024 * 1024
        if shutil.disk_usage(folder).free < needed:
            raise OSError(f'Không đủ dung lượng trống để ghép âm thanh. Cần khoảng {needed / 1024**3:.2f} GB. Các đoạn đã tạo vẫn được giữ để chạy tiếp.')

    def export(self, content, mode, provider, language, voice, speed, destination):
        self.check()
        destination = Path(destination)
        if destination.suffix.lower() not in ('.mp3', '.wav'):
            raise ValueError('Chọn định dạng .mp3 hoặc .wav.')
        if not .5 <= speed <= 2:
            raise ValueError('Tốc độ phải từ 0,5x đến 2x.')
        cues = parse_srt(content) if mode == 'SRT' else []
        if not content.strip():
            raise ValueError('Hãy nhập văn bản trước.')
        cache_root = destination.parent / '.tts-lite-cache'
        job_key = hashlib.sha256(json.dumps(['resume-v1', content, mode, provider, language, voice, speed], ensure_ascii=False).encode('utf-8')).hexdigest()
        cache = cache_root / job_key
        cache.mkdir(parents=True, exist_ok=True)
        # Temporary render files are disposable; complete online clips survive interruptions.
        with tempfile.TemporaryDirectory(prefix='tts-lite-', dir=destination.parent) as work:
            work = Path(work)
            final_wav = work / 'result.wav'
            issues = []
            report_data = None
            if mode == 'SRT':
                queue = []
                for index, cue in enumerate(cues):
                    self.check()
                    parts = []
                    chunks = split_text(cue.text)
                    for part_index, text in enumerate(chunks):
                        self.progress((index + part_index / len(chunks)) * 85 / len(cues), f'{provider}: đoạn {index + 1}/{len(cues)}, phần {part_index + 1}/{len(chunks)} — dùng lại phần đã xong')
                        try:
                            parts.append(self.clip(text, provider, language, voice, speed, cache))
                        except Cancelled:
                            raise
                        except Exception as exc:
                            raise RuntimeError(f'Dừng tại đoạn SRT {cue.number}: {exc}\nChạy lại cùng nội dung, dịch vụ và tốc độ để tiếp tục từ các đoạn đã lưu.') from exc
                    wav = work / f'{index}.wav'
                    if len(parts) == 1:
                        wav = parts[0]
                    else:
                        self.join(parts, wav)
                    queue.append(dict(line=cue.number, start_time=cue.start, end_time=cue.end,
                                      filename=str(wav), rate=f'{(speed - 1) * 100:+g}%'))
                self.progress(88, 'Đang căn âm thanh vào mốc SRT…')
                self.disk_space(destination.parent, max(c.end for c in cues) * 48, destination.suffix.lower() == '.mp3')
                issues, report = merge_timeline(queue, final_wav, work, self.ffmpeg, self.cancelled.is_set)
                self.check()
                report_data = json.loads(Path(report).read_text(encoding='utf-8'))
                if issues:
                    lines = ', '.join(str(issue['line']) for issue in issues[:10])
                    raise RuntimeError(f'Chưa xuất file vì có lỗi âm thanh tại đoạn {lines}: {issues[0]["reason"]}.\nCác đoạn đã tạo được giữ để chạy tiếp. File kết quả cũ không bị thay đổi.')
            else:
                chunks = split_text(content)
                clips = []
                for index, text in enumerate(chunks):
                    self.progress(index * 85 / len(chunks), f'{provider}: phần {index + 1}/{len(chunks)} — dùng lại phần đã xong')
                    clips.append(self.clip(text, provider, language, voice, speed, cache))
                frames = 0
                for path in clips:
                    with Reader(path) as audio:
                        frames += audio.getnframes()
                self.disk_space(destination.parent, frames, destination.suffix.lower() == '.mp3')
                self.join(clips, final_wav)
            self.check()
            self.progress(95, 'Đang xuất file âm thanh…')
            if destination.suffix.lower() == '.mp3':
                final = work / 'final.mp3'
                self.ffmpeg(['-y', '-i', final_wav, '-c:a', 'libmp3lame', '-b:a', '192k', final])
            else:
                final = final_wav
            self.check()
            os.replace(final, destination)
            if report_data is not None:
                destination.with_suffix('.timeline.json').write_text(json.dumps(report_data, ensure_ascii=False, indent=2), encoding='utf-8')
            self.progress(100, 'Đã xuất âm thanh.')
            # Resolve and constrain the generated cache path before removing this job's files.
            if cache.resolve().parent == cache_root.resolve() and cache.name == job_key:
                shutil.rmtree(cache, ignore_errors=True)
            return issues
