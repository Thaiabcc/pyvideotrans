# TTS Lite — gTTS + Edge TTS online

Bản thu gọn dành riêng cho nhập văn bản và import SRT, xuất MP3/WAV.
Không cần Python, GPU, PyTorch, CUDA hay model trên máy sử dụng.

1. Tải **TTS-Lite-Windows.zip** từ Releases và giải nén.
2. Mở **TTS-Lite.exe**.
3. Chọn gTTS hoặc Edge TTS; chọn ngôn ngữ/giọng đọc.
4. Nhập nội dung hoặc bấm **Import SRT / TXT**.
5. Chỉnh tốc độ nếu cần và bấm **Xuất âm thanh…**.

Cần Internet: nội dung được gửi tới Google hoặc Microsoft theo dịch vụ đã chọn.
gTTS dùng mã ngôn ngữ `vi` cho tiếng Việt. Edge có sẵn HoaiMy (nữ), NamMinh (nam),
và nút tải toàn bộ danh sách giọng. Hai dịch vụ online có thể giới hạn hoặc từ chối yêu cầu.

SRT giữ mốc thời gian gốc, thêm khoảng lặng và tự tăng tốc từng câu cho vừa mốc,
kể cả trên 2x, bằng FFmpeg atempo giữ cao độ. Giữ đủ lời, không bỏ trống câu chỉ vì
câu dài. Câu càng dài so với mốc thì giọng sẽ càng nhanh, có thể khó nghe.
Tốc độ người dùng chọn 0.5–2x là tốc độ nền; SRT tự tăng thêm khi cần.
SRT chồng mốc bị từ chối trước khi gọi dịch vụ. Báo cáo `.timeline.json` ghi các câu
đã tăng tốc trong `adjustments`; mục `issues` chỉ chứa lỗi xử lý thực sự.

## File lớn và khôi phục sau lỗi

- Văn bản / từng câu SRT được chia thành các yêu cầu tối đa 1.200 ký tự.
- Kết nối có timeout và thử lại; có thể bấm Hủy khi đang chạy.
- Các đoạn âm thanh hoàn chỉnh được lưu trong `.tts-lite-cache` cạnh file xuất.
  Khi lỗi mạng hoặc hủy, chạy lại **cùng nội dung, dịch vụ, giọng, tốc độ và thư mục xuất**
  để dùng lại các đoạn đã tạo. Cache của tác vụ được dọn khi xuất thành công.
- Cache bị hỏng được phát hiện và tạo lại. Có thể xóa `.tts-lite-cache` khi không cần
  tiếp tục một tác vụ cũ để giải phóng dung lượng.
- Ghép âm thanh theo từng khối nhỏ, hỗ trợ WAV RF64 khi vượt giới hạn 4 GiB của WAV thường.
- Kiểm tra dung lượng trống trước khi ghép; dọn file ghép tạm nếu lỗi/hủy.
- Không xuất file ghép thiếu câu khi có lỗi xử lý. File kết quả cũ chỉ được thay thế
  sau khi bản mới hoàn thành. SRT sai hoặc chồng mốc được báo trước khi gọi TTS.

Không thể bảo đảm mọi file / mọi lỗi dịch vụ đều xử lý được. File dài vẫn cần dung lượng
ổ đĩa cho cache và âm thanh tạm; Google / Microsoft có thể giới hạn hoặc ngừng dịch vụ.

FFmpeg nằm bên trong EXE và được giải nén tạm lúc mở ứng dụng. File tạm tạo âm thanh
được dọn sau tác vụ. WAV stereo 48 kHz có thể cần khoảng 0,69 GB mỗi giờ âm thanh
trong lúc xử lý; MP3 192 kbps khoảng 86 MB/giờ.

Build EXE chỉ chạy trên GitHub Actions. Mã căn timeline kế thừa từ bản pyVideoTrans
tùy chỉnh tại `D:\App\Pyvideo\pyvideotrans-main`; dự án gốc
https://github.com/jianchang512/pyvideotrans, giấy phép GPL-3.0 (LICENSE).
FFmpeg là thành phần của dự án https://ffmpeg.org; thông tin giấy phép trong gói tải.
