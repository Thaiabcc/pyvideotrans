# TTS Lite — gTTS + Edge TTS online

Bản thu gọn dành riêng cho nhập văn bản và import SRT, xuất MP3/WAV.
Không cần Python, GPU, PyTorch, CUDA hay model trên máy sử dụng.

1. Tải **TTS-Lite-Windows.zip** từ Releases và giải nén.
2. Mở **TTS-Lite.exe**.
3. Chọn gTTS hoặc Edge TTS; chọn ngôn ngữ/giọng đọc.
4. Nhập nội dung hoặc bấm **Import SRT / TXT**.
5. Chỉnh tốc độ nếu cần và bấm **Xuất âm thanh…**.

Cần Internet: nội dung được gửi tới Google hoặc Microsoft theo dịch vụ đã chọn.
gTTS dùng mã ngôn ngữ `vi` cho tiếng Việt. Edge có sẵn HoaiMy (nữ), NamMinh (nam),
và nút tải toàn bộ danh sách giọng. Hai dịch vụ online có thể giới hạn hoặc từ chối yêu cầu.

SRT giữ mốc thời gian gốc, thêm khoảng lặng và tự tăng tốc tối đa 2x mà không đổi cao độ.
SRT chồng mốc bị từ chối trước khi gọi dịch vụ. Đoạn không thể vừa mốc ở 2x sẽ để
im lặng trong bản ghép, giữ âm thanh riêng trong thư mục `-doan-can-sua` và báo cáo
`.timeline.json` cạnh file kết quả. Ứng dụng luôn hiện cảnh báo khi có đoạn như vậy.

FFmpeg nằm bên trong EXE và được giải nén tạm lúc mở ứng dụng. File tạm tạo âm thanh
được dọn sau tác vụ. WAV stereo 48 kHz có thể cần khoảng 0,69 GB mỗi giờ âm thanh
trong lúc xử lý; MP3 192 kbps khoảng 86 MB/giờ.

Build EXE chỉ chạy trên GitHub Actions. Mã căn timeline kế thừa từ bản pyVideoTrans
tùy chỉnh tại `D:\App\Pyvideo\pyvideotrans-main`; dự án gốc
https://github.com/jianchang512/pyvideotrans, giấy phép GPL-3.0 (LICENSE).
FFmpeg là thành phần của dự án https://ffmpeg.org; thông tin giấy phép trong gói tải.
