"""Run ONLY on the GitHub Windows runner."""
from pathlib import Path
import importlib.metadata
import json
import shutil
import subprocess
import sys
import zipfile

import imageio_ffmpeg

root = Path(__file__).resolve().parent
shutil.copy2(imageio_ffmpeg.get_ffmpeg_exe(), root / 'ffmpeg.exe')
subprocess.run([sys.executable, '-m', 'unittest', '-v', 'test_core'], cwd=root, check=True)
subprocess.run([sys.executable, '-m', 'PyInstaller', '--noconfirm', '--clean', '--onefile', '--windowed',
                '--name', 'TTS-Lite', '--icon', 'icon.ico', '--add-binary', 'ffmpeg.exe;.', '--add-data', 'icon.ico;.',
                '--collect-data', 'certifi', '--collect-data', 'gtts', '--collect-data', 'edge_tts', 'app.py'], cwd=root, check=True)
exe = root / 'dist/TTS-Lite.exe'
subprocess.run([str(exe), '--smoke-test'], cwd=root, check=True, timeout=120)
release = root / 'release'
release.mkdir(exist_ok=True)
shutil.copy2(exe, release / exe.name)
shutil.copy2(root / 'README.md', release / 'HUONG-DAN.md')
shutil.copy2(root / 'LICENSE', release / 'LICENSE')
subprocess.run([sys.executable, 'online_check.py'], cwd=root, check=True, timeout=300)
shutil.copy2(root / 'online-check.json', release / 'online-check.json')
licenses = release / 'THIRD-PARTY-LICENSES'
licenses.mkdir(exist_ok=True)
for name in ['gTTS', 'edge-tts', 'imageio-ffmpeg', 'certifi', 'aiohttp', 'requests', 'click', 'charset-normalizer', 'urllib3', 'idna']:
    dist = importlib.metadata.distribution(name)
    for file in dist.files or []:
        if any(word in str(file).lower() for word in ['license', 'copying', 'notice']):
            path = Path(dist.locate_file(file))
            if path.is_file():
                shutil.copy2(path, licenses / (name + '-' + path.name))
ffmpeg_license = subprocess.run([str(root / 'ffmpeg.exe'), '-L'], capture_output=True, text=True, check=True)
(licenses / 'FFmpeg.txt').write_text('FFmpeg executable bundled from the imageio-ffmpeg 0.6.0 Windows wheel. Project and source: https://ffmpeg.org ; binary distribution: https://github.com/imageio/imageio-binaries/tree/master/ffmpeg .\n\n' + ffmpeg_license.stdout + ffmpeg_license.stderr, encoding='utf-8')
sizes = {'exe_bytes': exe.stat().st_size, 'installed_bytes': sum(p.stat().st_size for p in release.rglob('*') if p.is_file()), 'embedded_ffmpeg_bytes': (root / 'ffmpeg.exe').stat().st_size}
archive = root / 'TTS-Lite-Windows.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for p in release.rglob('*'):
        if p.is_file():
            z.write(p, p.relative_to(release))
sizes['download_bytes'] = archive.stat().st_size
(root / 'build-sizes.json').write_text(json.dumps(sizes, indent=2), encoding='utf-8')
print('SIZE_REPORT=' + json.dumps(sizes), flush=True)
